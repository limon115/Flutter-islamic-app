package com.khalid.islamicprayertimes.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.khalid.islamicprayertimes.utils.NotificationHelper;
import com.khalid.islamicprayertimes.utils.PrayerTimesCalculator;
import com.khalid.islamicprayertimes.utils.PrefsManager;

import java.util.Calendar;
import java.util.TimeZone;

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) ||
                "android.intent.action.QUICKBOOT_POWERON".equals(action)) {
            rescheduleAlarms(context);
        }
    }

    private void rescheduleAlarms(Context context) {
        PrefsManager prefs = new PrefsManager(context);
        double lat = prefs.getLastLat();
        double lon = prefs.getLastLon();

        PrayerTimesCalculator calculator = new PrayerTimesCalculator(lat, lon);
        calculator.setCalcMethod(prefs.getCalcMethod());
        calculator.setAsrJuristic(prefs.getAsrMethod());

        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"));
        double[] times = calculator.getPrayerTimesDouble(
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH)
        );

        String[] names = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
        String[] keys = {PrefsManager.KEY_NOTIF_FAJR, PrefsManager.KEY_NOTIF_DHUHR,
                PrefsManager.KEY_NOTIF_ASR, PrefsManager.KEY_NOTIF_MAGHRIB, PrefsManager.KEY_NOTIF_ISHA};
        int[] timeIndices = {PrayerTimesCalculator.FAJR, PrayerTimesCalculator.DHUHR,
                PrayerTimesCalculator.ASR, PrayerTimesCalculator.MAGHRIB, PrayerTimesCalculator.ISHA};

        for (int i = 0; i < names.length; i++) {
            if (prefs.getNotifEnabled(keys[i])) {
                NotificationHelper.schedulePrayerAlarm(context, names[i], times[timeIndices[i]], i + 100);
            }
        }
    }
}
