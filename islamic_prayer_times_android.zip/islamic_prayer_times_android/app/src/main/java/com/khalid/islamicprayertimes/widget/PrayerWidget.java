package com.khalid.islamicprayertimes.widget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import com.khalid.islamicprayertimes.R;
import com.khalid.islamicprayertimes.utils.PrayerTimesCalculator;
import com.khalid.islamicprayertimes.utils.PrefsManager;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class PrayerWidget extends AppWidgetProvider {

    private static final String ACTION_UPDATE = "com.khalid.islamicprayertimes.WIDGET_UPDATE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId);
        }
        scheduleNextUpdate(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_UPDATE.equals(intent.getAction())) {
            updateAllWidgets(context);
        }
    }

    public static void updateAllWidgets(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName componentName = new ComponentName(context, PrayerWidget.class);
        int[] ids = manager.getAppWidgetIds(componentName);
        for (int id : ids) {
            updateWidget(context, manager, id);
        }
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int widgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_prayer);

        PrefsManager prefs = new PrefsManager(context);
        double lat = prefs.getLastLat();
        double lon = prefs.getLastLon();
        String locationName = prefs.getLastLocationName();

        PrayerTimesCalculator calculator = new PrayerTimesCalculator(lat, lon);
        calculator.setCalcMethod(prefs.getCalcMethod());

        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"));
        double[] times = calculator.getPrayerTimesDouble(
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH)
        );

        double iftarTime = times[PrayerTimesCalculator.MAGHRIB];
        double suhurTime = times[PrayerTimesCalculator.FAJR];

        // Compute countdown
        double currentHours = cal.get(Calendar.HOUR_OF_DAY) +
                cal.get(Calendar.MINUTE) / 60.0 +
                cal.get(Calendar.SECOND) / 3600.0;

        double targetTime;
        String label;

        if (currentHours >= iftarTime) {
            targetTime = suhurTime + 24;
            label = "Suhur";
        } else {
            targetTime = iftarTime;
            label = "Iftar";
        }

        double diffHours = targetTime - currentHours;
        if (diffHours < 0) diffHours += 24;

        int hours = (int) Math.floor(diffHours);
        int minutes = (int) Math.floor((diffHours - hours) * 60);

        String countdown = String.format(Locale.getDefault(), "%dh %02dm", hours, minutes);
        String iftarFormatted = PrayerTimesCalculator.formatTime(iftarTime, prefs.getTimeFormat());

        views.setTextViewText(R.id.widget_label, label + " Countdown");
        views.setTextViewText(R.id.widget_countdown, countdown);
        views.setTextViewText(R.id.widget_iftar_time, "Iftar: " + iftarFormatted);
        views.setTextViewText(R.id.widget_location, locationName);

        manager.updateAppWidget(widgetId, views);
    }

    private static void scheduleNextUpdate(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Intent intent = new Intent(context, PrayerWidget.class);
        intent.setAction(ACTION_UPDATE);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        long interval = 60 * 1000L; // Update every minute
        alarmManager.setRepeating(
                AlarmManager.RTC,
                System.currentTimeMillis() + interval,
                interval,
                pendingIntent
        );
    }

    @Override
    public void onEnabled(Context context) {
        scheduleNextUpdate(context);
    }

    @Override
    public void onDisabled(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            Intent intent = new Intent(context, PrayerWidget.class);
            intent.setAction(ACTION_UPDATE);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            alarmManager.cancel(pendingIntent);
        }
    }
}
