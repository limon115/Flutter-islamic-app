package com.khalid.islamicprayertimes.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefsManager {

    private static final String PREFS_NAME = "IslamicPrayerTimesPrefs";

    // Keys
    public static final String KEY_DARK_MODE = "dark_mode";
    public static final String KEY_TIME_FORMAT = "time_format"; // 0=24h, 1=12h
    public static final String KEY_USER_NAME = "user_name";
    public static final String KEY_PROFILE_IMAGE_URI = "profile_image_uri";
    public static final String KEY_LAST_LAT = "last_lat";
    public static final String KEY_LAST_LON = "last_lon";
    public static final String KEY_LAST_LOCATION_NAME = "last_location_name";
    public static final String KEY_CALC_METHOD = "calc_method";
    public static final String KEY_ASR_METHOD = "asr_method";

    // Notification keys
    public static final String KEY_NOTIF_FAJR = "notif_fajr";
    public static final String KEY_NOTIF_DHUHR = "notif_dhuhr";
    public static final String KEY_NOTIF_ASR = "notif_asr";
    public static final String KEY_NOTIF_MAGHRIB = "notif_maghrib";
    public static final String KEY_NOTIF_ISHA = "notif_isha";

    // Custom time keys
    public static final String KEY_CUSTOM_FAJR = "custom_fajr";
    public static final String KEY_CUSTOM_DHUHR = "custom_dhuhr";
    public static final String KEY_CUSTOM_ASR = "custom_asr";
    public static final String KEY_CUSTOM_MAGHRIB = "custom_maghrib";
    public static final String KEY_CUSTOM_ISHA = "custom_isha";
    public static final String KEY_USE_CUSTOM_TIMES = "use_custom_times";

    private final SharedPreferences prefs;

    public PrefsManager(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public boolean getDarkMode() {
        return prefs.getBoolean(KEY_DARK_MODE, false);
    }

    public void setDarkMode(boolean dark) {
        prefs.edit().putBoolean(KEY_DARK_MODE, dark).apply();
    }

    public int getTimeFormat() {
        return prefs.getInt(KEY_TIME_FORMAT, PrayerTimesCalculator.TIME_12H);
    }

    public void setTimeFormat(int format) {
        prefs.edit().putInt(KEY_TIME_FORMAT, format).apply();
    }

    public String getUserName() {
        return prefs.getString(KEY_USER_NAME, "");
    }

    public void setUserName(String name) {
        prefs.edit().putString(KEY_USER_NAME, name).apply();
    }

    public String getProfileImageUri() {
        return prefs.getString(KEY_PROFILE_IMAGE_URI, "");
    }

    public void setProfileImageUri(String uri) {
        prefs.edit().putString(KEY_PROFILE_IMAGE_URI, uri).apply();
    }

    public double getLastLat() {
        return Double.longBitsToDouble(prefs.getLong(KEY_LAST_LAT, Double.doubleToLongBits(23.8103)));
    }

    public double getLastLon() {
        return Double.longBitsToDouble(prefs.getLong(KEY_LAST_LON, Double.doubleToLongBits(90.4125)));
    }

    public void setLastLocation(double lat, double lon) {
        prefs.edit()
                .putLong(KEY_LAST_LAT, Double.doubleToLongBits(lat))
                .putLong(KEY_LAST_LON, Double.doubleToLongBits(lon))
                .apply();
    }

    public String getLastLocationName() {
        return prefs.getString(KEY_LAST_LOCATION_NAME, "Dhaka, Bangladesh");
    }

    public void setLastLocationName(String name) {
        prefs.edit().putString(KEY_LAST_LOCATION_NAME, name).apply();
    }

    public boolean getNotifEnabled(String key) {
        return prefs.getBoolean(key, true);
    }

    public void setNotifEnabled(String key, boolean enabled) {
        prefs.edit().putBoolean(key, enabled).apply();
    }

    public boolean isUseCustomTimes() {
        return prefs.getBoolean(KEY_USE_CUSTOM_TIMES, false);
    }

    public void setUseCustomTimes(boolean use) {
        prefs.edit().putBoolean(KEY_USE_CUSTOM_TIMES, use).apply();
    }

    public String getCustomTime(String key) {
        return prefs.getString(key, "");
    }

    public void setCustomTime(String key, String time) {
        prefs.edit().putString(key, time).apply();
    }

    public int getCalcMethod() {
        return prefs.getInt(KEY_CALC_METHOD, PrayerTimesCalculator.METHOD_KARACHI);
    }

    public void setCalcMethod(int method) {
        prefs.edit().putInt(KEY_CALC_METHOD, method).apply();
    }

    public int getAsrMethod() {
        return prefs.getInt(KEY_ASR_METHOD, PrayerTimesCalculator.ASR_HANAFI);
    }

    public void setAsrMethod(int method) {
        prefs.edit().putInt(KEY_ASR_METHOD, method).apply();
    }
}
