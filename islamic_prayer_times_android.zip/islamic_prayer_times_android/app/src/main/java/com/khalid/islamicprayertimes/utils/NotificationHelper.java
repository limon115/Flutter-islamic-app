package com.khalid.islamicprayertimes.utils;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.khalid.islamicprayertimes.receivers.PrayerNotificationReceiver;

import java.util.Calendar;
import java.util.TimeZone;

public class NotificationHelper {

    public static final String CHANNEL_ID = "prayer_times_channel";
    public static final String CHANNEL_NAME = "Prayer Times";
    public static final String EXTRA_PRAYER_NAME = "prayer_name";

    public static void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Prayer time notifications");
            channel.enableVibration(true);
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    public static void schedulePrayerAlarm(Context context, String prayerName, double prayerTime, int requestCode) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Intent intent = new Intent(context, PrayerNotificationReceiver.class);
        intent.setAction("com.khalid.islamicprayertimes.PRAYER_ALARM");
        intent.putExtra(EXTRA_PRAYER_NAME, prayerName);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Calendar prayerCalendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"));
        int hours = (int) Math.floor(prayerTime);
        int minutes = (int) Math.floor((prayerTime - hours) * 60);
        prayerCalendar.set(Calendar.HOUR_OF_DAY, hours);
        prayerCalendar.set(Calendar.MINUTE, minutes);
        prayerCalendar.set(Calendar.SECOND, 0);
        prayerCalendar.set(Calendar.MILLISECOND, 0);

        // If time already passed today, skip scheduling
        if (prayerCalendar.getTimeInMillis() <= System.currentTimeMillis()) {
            return;
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            prayerCalendar.getTimeInMillis(),
                            pendingIntent
                    );
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        prayerCalendar.getTimeInMillis(),
                        pendingIntent
                );
            }
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    public static void cancelPrayerAlarm(Context context, int requestCode) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;
        Intent intent = new Intent(context, PrayerNotificationReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        alarmManager.cancel(pendingIntent);
    }
}
