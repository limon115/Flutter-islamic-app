package com.khalid.islamicprayertimes.activities;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;

import com.khalid.islamicprayertimes.R;
import com.khalid.islamicprayertimes.utils.PrefsManager;

public class SettingsActivity extends AppCompatActivity {

    private PrefsManager prefs;

    private Switch switchDarkMode;
    private Switch switchTimeFormat;
    private Switch switchNotifFajr;
    private Switch switchNotifDhuhr;
    private Switch switchNotifAsr;
    private Switch switchNotifMaghrib;
    private Switch switchNotifIsha;
    private Switch switchCustomTimes;

    private EditText etUserName;
    private ImageView ivProfileImage;

    private ActivityResultLauncher<String> imagePickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        prefs = new PrefsManager(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        initViews();
        loadSettings();
        setupListeners();
        setupImagePicker();
    }

    private void initViews() {
        switchDarkMode = findViewById(R.id.switch_dark_mode);
        switchTimeFormat = findViewById(R.id.switch_time_format);
        switchNotifFajr = findViewById(R.id.switch_notif_fajr);
        switchNotifDhuhr = findViewById(R.id.switch_notif_dhuhr);
        switchNotifAsr = findViewById(R.id.switch_notif_asr);
        switchNotifMaghrib = findViewById(R.id.switch_notif_maghrib);
        switchNotifIsha = findViewById(R.id.switch_notif_isha);
        switchCustomTimes = findViewById(R.id.switch_custom_times);
        etUserName = findViewById(R.id.et_user_name);
        ivProfileImage = findViewById(R.id.iv_profile_image);

        CardView cardDeveloperInfo = findViewById(R.id.card_developer_info);
        if (cardDeveloperInfo != null) {
            cardDeveloperInfo.setOnClickListener(v -> {
                startActivity(new Intent(SettingsActivity.this, DeveloperInfoActivity.class));
            });
        }
    }

    private void loadSettings() {
        if (switchDarkMode != null) switchDarkMode.setChecked(prefs.getDarkMode());
        if (switchTimeFormat != null)
            switchTimeFormat.setChecked(prefs.getTimeFormat() == 0); // 0=24h = checked
        if (switchNotifFajr != null)
            switchNotifFajr.setChecked(prefs.getNotifEnabled(PrefsManager.KEY_NOTIF_FAJR));
        if (switchNotifDhuhr != null)
            switchNotifDhuhr.setChecked(prefs.getNotifEnabled(PrefsManager.KEY_NOTIF_DHUHR));
        if (switchNotifAsr != null)
            switchNotifAsr.setChecked(prefs.getNotifEnabled(PrefsManager.KEY_NOTIF_ASR));
        if (switchNotifMaghrib != null)
            switchNotifMaghrib.setChecked(prefs.getNotifEnabled(PrefsManager.KEY_NOTIF_MAGHRIB));
        if (switchNotifIsha != null)
            switchNotifIsha.setChecked(prefs.getNotifEnabled(PrefsManager.KEY_NOTIF_ISHA));
        if (switchCustomTimes != null)
            switchCustomTimes.setChecked(prefs.isUseCustomTimes());
        if (etUserName != null) etUserName.setText(prefs.getUserName());

        String imageUri = prefs.getProfileImageUri();
        if (!imageUri.isEmpty() && ivProfileImage != null) {
            try {
                ivProfileImage.setImageURI(Uri.parse(imageUri));
            } catch (Exception e) {
                ivProfileImage.setImageResource(R.drawable.ic_profile_placeholder);
            }
        }
    }

    private void setupListeners() {
        if (switchDarkMode != null) {
            switchDarkMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
                prefs.setDarkMode(isChecked);
                AppCompatDelegate.setDefaultNightMode(
                        isChecked ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
                );
                recreate();
            });
        }

        if (switchTimeFormat != null) {
            switchTimeFormat.setOnCheckedChangeListener((buttonView, isChecked) -> {
                prefs.setTimeFormat(isChecked ? 0 : 1); // 0=24h, 1=12h
            });
        }

        if (switchNotifFajr != null)
            switchNotifFajr.setOnCheckedChangeListener((b, c) ->
                    prefs.setNotifEnabled(PrefsManager.KEY_NOTIF_FAJR, c));

        if (switchNotifDhuhr != null)
            switchNotifDhuhr.setOnCheckedChangeListener((b, c) ->
                    prefs.setNotifEnabled(PrefsManager.KEY_NOTIF_DHUHR, c));

        if (switchNotifAsr != null)
            switchNotifAsr.setOnCheckedChangeListener((b, c) ->
                    prefs.setNotifEnabled(PrefsManager.KEY_NOTIF_ASR, c));

        if (switchNotifMaghrib != null)
            switchNotifMaghrib.setOnCheckedChangeListener((b, c) ->
                    prefs.setNotifEnabled(PrefsManager.KEY_NOTIF_MAGHRIB, c));

        if (switchNotifIsha != null)
            switchNotifIsha.setOnCheckedChangeListener((b, c) ->
                    prefs.setNotifEnabled(PrefsManager.KEY_NOTIF_ISHA, c));

        if (switchCustomTimes != null)
            switchCustomTimes.setOnCheckedChangeListener((b, c) -> prefs.setUseCustomTimes(c));

        if (ivProfileImage != null) {
            ivProfileImage.setOnClickListener(v -> imagePickerLauncher.launch("image/*"));
        }

        TextView tvSave = findViewById(R.id.tv_save_profile);
        if (tvSave != null) {
            tvSave.setOnClickListener(v -> {
                if (etUserName != null) {
                    prefs.setUserName(etUserName.getText().toString().trim());
                    Toast.makeText(this, "Profile saved!", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void setupImagePicker() {
        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        try {
                            getContentResolver().takePersistableUriPermission(
                                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } catch (Exception e) {
                            // ignore if not persistable
                        }
                        prefs.setProfileImageUri(uri.toString());
                        if (ivProfileImage != null) ivProfileImage.setImageURI(uri);
                    }
                }
        );
    }
}
