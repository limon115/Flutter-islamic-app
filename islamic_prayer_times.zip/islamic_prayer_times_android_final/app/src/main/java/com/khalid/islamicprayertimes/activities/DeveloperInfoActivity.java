package com.khalid.islamicprayertimes.activities;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.khalid.islamicprayertimes.R;

public class DeveloperInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_developer_info);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Developer Info");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        TextView tvDeveloperName = findViewById(R.id.tv_developer_name);
        TextView tvRole = findViewById(R.id.tv_role);
        TextView tvCountry = findViewById(R.id.tv_country);
        TextView tvAppPurpose = findViewById(R.id.tv_app_purpose);
        TextView tvContact = findViewById(R.id.tv_contact);
        TextView tvVersion = findViewById(R.id.tv_version);

        if (tvDeveloperName != null) tvDeveloperName.setText("Khalid Hasan Limon");
        if (tvRole != null) tvRole.setText("Student Developer");
        if (tvCountry != null) tvCountry.setText("Bangladesh");
        if (tvAppPurpose != null)
            tvAppPurpose.setText("Islamic prayer assistance for Muslims — providing accurate Suhur, Iftar, and Namaz times based on GPS location for Muslims in Bangladesh.");
        if (tvContact != null) tvContact.setText("Contact: (Available upon request)");
        if (tvVersion != null) tvVersion.setText("Version: 1.0.0");
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
