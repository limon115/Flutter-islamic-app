package com.khalid.islamicprayertimes.models;

public class PrayerTimes {
    private String fajr;
    private String sunrise;
    private String dhuhr;
    private String asr;
    private String sunset;
    private String maghrib;
    private String isha;

    private double fajrDouble;
    private double sunriseDouble;
    private double dhuhrDouble;
    private double asrDouble;
    private double sunsetDouble;
    private double maghribDouble;
    private double ishaDouble;

    private String locationName;
    private long calculationDate;

    public PrayerTimes() {}

    public String getFajr() { return fajr; }
    public void setFajr(String fajr) { this.fajr = fajr; }

    public String getSunrise() { return sunrise; }
    public void setSunrise(String sunrise) { this.sunrise = sunrise; }

    public String getDhuhr() { return dhuhr; }
    public void setDhuhr(String dhuhr) { this.dhuhr = dhuhr; }

    public String getAsr() { return asr; }
    public void setAsr(String asr) { this.asr = asr; }

    public String getSunset() { return sunset; }
    public void setSunset(String sunset) { this.sunset = sunset; }

    public String getMaghrib() { return maghrib; }
    public void setMaghrib(String maghrib) { this.maghrib = maghrib; }

    public String getIsha() { return isha; }
    public void setIsha(String isha) { this.isha = isha; }

    public double getFajrDouble() { return fajrDouble; }
    public void setFajrDouble(double fajrDouble) { this.fajrDouble = fajrDouble; }

    public double getSunriseDouble() { return sunriseDouble; }
    public void setSunriseDouble(double sunriseDouble) { this.sunriseDouble = sunriseDouble; }

    public double getDhuhrDouble() { return dhuhrDouble; }
    public void setDhuhrDouble(double dhuhrDouble) { this.dhuhrDouble = dhuhrDouble; }

    public double getAsrDouble() { return asrDouble; }
    public void setAsrDouble(double asrDouble) { this.asrDouble = asrDouble; }

    public double getSunsetDouble() { return sunsetDouble; }
    public void setSunsetDouble(double sunsetDouble) { this.sunsetDouble = sunsetDouble; }

    public double getMaghribDouble() { return maghribDouble; }
    public void setMaghribDouble(double maghribDouble) { this.maghribDouble = maghribDouble; }

    public double getIshaDouble() { return ishaDouble; }
    public void setIshaDouble(double ishaDouble) { this.ishaDouble = ishaDouble; }

    public String getLocationName() { return locationName; }
    public void setLocationName(String locationName) { this.locationName = locationName; }

    public long getCalculationDate() { return calculationDate; }
    public void setCalculationDate(long calculationDate) { this.calculationDate = calculationDate; }

    /** Suhur = Fajr */
    public String getSuhur() { return fajr; }
    public double getSuhurDouble() { return fajrDouble; }

    /** Iftar = Maghrib */
    public String getIftar() { return maghrib; }
    public double getIftarDouble() { return maghribDouble; }
}
