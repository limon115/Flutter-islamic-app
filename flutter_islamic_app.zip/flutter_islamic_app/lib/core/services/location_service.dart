import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:hive_flutter/hive_flutter.dart';

class LocationService {
  static const String _lastLocationBoxName = 'lastLocationBox';
  static const String _latitudeKey = 'latitude';
  static const String _longitudeKey = 'longitude';
  static const String _locationNameKey = 'locationName';

  /// Request location permission and return status
  static Future<bool> requestLocationPermission() async {
    try {
      LocationPermission permission = await Geolocator.checkPermission();

      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.deniedForever) {
        return false;
      }

      return permission == LocationPermission.whileInUse ||
          permission == LocationPermission.always;
    } catch (e) {
      print('Error requesting location permission: $e');
      return false;
    }
  }

  /// Get current device location
  static Future<Position?> getCurrentLocation() async {
    try {
      final hasPermission = await requestLocationPermission();
      if (!hasPermission) {
        return null;
      }

      final position = await Geolocator.getCurrentPosition(
        timeLimit: const Duration(seconds: 30),
        forceAndroidLocationManager: false,
      );

      // Save to local storage for fallback
      await _saveLastLocation(
        position.latitude,
        position.longitude,
        '',
      );

      return position;
    } on TimeoutException {
      // Return last known location if current request times out
      return await getLastKnownLocation();
    } catch (e) {
      print('Error getting current location: $e');
      return await getLastKnownLocation();
    }
  }

  /// Get last known location from local storage
  static Future<Position?> getLastKnownLocation() async {
    try {
      final box = await Hive.openBox(_lastLocationBoxName);
      final latitude = box.get(_latitudeKey) as double?;
      final longitude = box.get(_longitudeKey) as double?;

      if (latitude != null && longitude != null) {
        return Position(
          longitude: longitude,
          latitude: latitude,
          timestamp: DateTime.now(),
          accuracy: 0,
          altitude: 0,
          altitudeAccuracy: 0,
          heading: 0,
          headingAccuracy: 0,
          speed: 0,
          speedAccuracy: 0,
        );
      }
      return null;
    } catch (e) {
      print('Error getting last known location: $e');
      return null;
    }
  }

  /// Reverse geocode coordinates to location name
  static Future<String> getLocationName(
    double latitude,
    double longitude,
  ) async {
    try {
      final placemarks = await placemarkFromCoordinates(
        latitude,
        longitude,
      );

      if (placemarks.isNotEmpty) {
        final pm = placemarks.first;

        // Build location string: District, Division, Country
        final parts = <String>[];

        if (pm.administrativeArea?.isNotEmpty ?? false) {
          parts.add(pm.administrativeArea!);
        }
        if (pm.subAdministrativeArea?.isNotEmpty ?? false) {
          if (!parts.contains(pm.subAdministrativeArea)) {
            parts.add(pm.subAdministrativeArea!);
          }
        }
        if (pm.locality?.isNotEmpty ?? false) {
          if (!parts.contains(pm.locality)) {
            parts.add(pm.locality!);
          }
        }
        if (pm.name?.isNotEmpty ?? false) {
          if (!parts.contains(pm.name)) {
            parts.add(pm.name!);
          }
        }

        final locationName = parts.join(', ');

        // Save to local storage
        await _saveLastLocation(latitude, longitude, locationName);

        return locationName.isEmpty
            ? 'Bangladesh (${latitude.toStringAsFixed(4)}, ${longitude.toStringAsFixed(4)})'
            : locationName;
      }

      return 'Bangladesh (${latitude.toStringAsFixed(4)}, ${longitude.toStringAsFixed(4)})';
    } catch (e) {
      print('Error reverse geocoding: $e');
      return 'Bangladesh (${latitude.toStringAsFixed(4)}, ${longitude.toStringAsFixed(4)})';
    }
  }

  /// Save last known location to local storage
  static Future<void> _saveLastLocation(
    double latitude,
    double longitude,
    String locationName,
  ) async {
    try {
      final box = await Hive.openBox(_lastLocationBoxName);
      await box.put(_latitudeKey, latitude);
      await box.put(_longitudeKey, longitude);
      if (locationName.isNotEmpty) {
        await box.put(_locationNameKey, locationName);
      }
    } catch (e) {
      print('Error saving location: $e');
    }
  }

  /// Get distance between two coordinates in kilometers
  static double getDistanceInKm(
    double lat1,
    double lon1,
    double lat2,
    double lon2,
  ) {
    return Geolocator.distanceBetween(lat1, lon1, lat2, lon2) / 1000;
  }

  /// Check if location services are enabled
  static Future<bool> isLocationServiceEnabled() async {
    return await Geolocator.isLocationServiceEnabled();
  }

  /// Open app settings for location
  static Future<bool> openLocationSettings() async {
    return await Geolocator.openLocationSettings();
  }

  /// Open app app settings
  static Future<bool> openAppSettings() async {
    return await Geolocator.openAppSettings();
  }
}
