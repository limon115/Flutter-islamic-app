import 'package:adhan/adhan.dart';

class PrayerTimeService {
  // Muslim World League - Fajr angle: 18, Isha angle: 17
  // This is widely used and recommended for Bangladesh
  static const CalculationMethod calculationMethod =
      CalculationMethod.MuslimWorldLeague;

  static const Madhab madhab = Madhab.Hanafi;

  /// Calculate prayer times for a given date and location
  /// Returns a map with prayer names as keys and DateTime as values
  static Map<String, DateTime> calculatePrayerTimes({
    required double latitude,
    required double longitude,
    required DateTime date,
  }) {
    // Create coordinates
    final coords = Coordinates(latitude, longitude);

    // Create prayer times parameters
    final params = CalculationParameters.from(calculationMethod);
    params.madhab = madhab;

    // Create PrayerTimes instance
    final prayerTimes = PrayerTimes(coords, date, params);

    return {
      'Fajr': prayerTimes.fajr,
      'Sunrise': prayerTimes.sunrise,
      'Dhuhr': prayerTimes.dhuhr,
      'Asr': prayerTimes.asr,
      'Maghrib': prayerTimes.maghrib,
      'Isha': prayerTimes.isha,
    };
  }

  /// Get Suhur time (Fajr start)
  static DateTime getSuhurTime({
    required double latitude,
    required double longitude,
    required DateTime date,
  }) {
    final times = calculatePrayerTimes(
      latitude: latitude,
      longitude: longitude,
      date: date,
    );
    return times['Fajr']!;
  }

  /// Get Iftar time (Maghrib/Sunset)
  static DateTime getIftarTime({
    required double latitude,
    required double longitude,
    required DateTime date,
  }) {
    final times = calculatePrayerTimes(
      latitude: latitude,
      longitude: longitude,
      date: date,
    );
    return times['Maghrib']!;
  }

  /// Get all 5 prayer times for a date
  static Map<String, DateTime> getDailyPrayers({
    required double latitude,
    required double longitude,
    required DateTime date,
  }) {
    final allTimes = calculatePrayerTimes(
      latitude: latitude,
      longitude: longitude,
      date: date,
    );

    // Return only the 5 main prayers
    return {
      'Fajr': allTimes['Fajr']!,
      'Dhuhr': allTimes['Dhuhr']!,
      'Asr': allTimes['Asr']!,
      'Maghrib': allTimes['Maghrib']!,
      'Isha': allTimes['Isha']!,
    };
  }

  /// Get next prayer time from current time
  static String? getNextPrayer({
    required DateTime now,
    required Map<String, DateTime> prayerTimes,
  }) {
    const prayerOrder = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

    for (final prayer in prayerOrder) {
      if (prayerTimes[prayer]!.isAfter(now)) {
        return prayer;
      }
    }

    // If no prayer time left today, next prayer is Fajr tomorrow
    return 'Fajr';
  }

  /// Get time remaining until next prayer
  static Duration getTimeUntilNextPrayer({
    required DateTime now,
    required Map<String, DateTime> prayerTimes,
  }) {
    const prayerOrder = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

    for (final prayer in prayerOrder) {
      final prayerTime = prayerTimes[prayer]!;
      if (prayerTime.isAfter(now)) {
        return prayerTime.difference(now);
      }
    }

    // Return time until Fajr tomorrow
    final fajrTomorrow = prayerTimes['Fajr']!.add(const Duration(days: 1));
    return fajrTomorrow.difference(now);
  }
}
