import 'package:flutter/material.dart';
import '../models/prayer_time_model.dart';
import '../services/prayer_time_service.dart';
import '../services/storage_service.dart';

class PrayerTimeProvider extends ChangeNotifier {
  Map<String, DateTime> _todayPrayers = {};
  Map<String, DateTime> _tomorrowPrayers = {};
  double _latitude = 0.0;
  double _longitude = 0.0;
  String _location = '';
  bool _isLoading = false;
  String? _error;
  DateTime? _lastCalculatedDate;

  // Getters
  Map<String, DateTime> get todayPrayers => _todayPrayers;
  Map<String, DateTime> get tomorrowPrayers => _tomorrowPrayers;
  double get latitude => _latitude;
  double get longitude => _longitude;
  String get location => _location;
  bool get isLoading => _isLoading;
  String? get error => _error;

  DateTime get suhurTime {
    if (_todayPrayers.containsKey('Fajr')) {
      return _todayPrayers['Fajr']!;
    }
    return DateTime.now();
  }

  DateTime get iftarTime {
    if (_todayPrayers.containsKey('Maghrib')) {
      return _todayPrayers['Maghrib']!;
    }
    return DateTime.now();
  }

  /// Update location and recalculate prayer times
  Future<void> updateLocation(
    double? latitude,
    double? longitude,
    String? location,
  ) async {
    if (latitude == null || longitude == null) {
      return;
    }

    if (_latitude == latitude &&
        _longitude == longitude &&
        _location == (location ?? '')) {
      return; // No change needed
    }

    _latitude = latitude;
    _longitude = longitude;
    _location = location ?? '';

    await calculatePrayerTimes();
  }

  /// Calculate prayer times for today and tomorrow
  Future<void> calculatePrayerTimes() async {
    if (_latitude == 0.0 || _longitude == 0.0) {
      return;
    }

    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      final now = DateTime.now();

      // Check if we need to recalculate
      if (_lastCalculatedDate != null &&
          _lastCalculatedDate!.year == now.year &&
          _lastCalculatedDate!.month == now.month &&
          _lastCalculatedDate!.day == now.day) {
        // Already calculated for today
        _isLoading = false;
        notifyListeners();
        return;
      }

      // Calculate today's prayer times
      _todayPrayers = PrayerTimeService.getDailyPrayers(
        latitude: _latitude,
        longitude: _longitude,
        date: now,
      );

      // Calculate tomorrow's prayer times
      final tomorrow = now.add(const Duration(days: 1));
      _tomorrowPrayers = PrayerTimeService.getDailyPrayers(
        latitude: _latitude,
        longitude: _longitude,
        date: tomorrow,
      );

      // Save to local storage for offline access
      await _savePrayerTimesToStorage(now);

      _lastCalculatedDate = now;
      _error = null;
    } catch (e) {
      _error = 'Error calculating prayer times: ${e.toString()}';
      print('Prayer time calculation error: $e');

      // Try to load from cache
      await _loadPrayerTimesFromStorage();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Save prayer times to local storage
  Future<void> _savePrayerTimesToStorage(DateTime date) async {
    try {
      // Save individual prayer times
      for (final entry in _todayPrayers.entries) {
        final prayerTime = PrayerTime(
          name: entry.key,
          date: date,
          calculatedTime: entry.value,
          location: _location,
        );
        await StorageService.savePrayerTime(prayerTime);
      }

      // Save daily schedule
      final schedule = DailyPrayerSchedule(
        date: date,
        prayers: _todayPrayers.entries
            .map((e) => PrayerTime(
                  name: e.key,
                  date: date,
                  calculatedTime: e.value,
                  location: _location,
                ))
            .toList(),
        location: _location,
        suhur: _todayPrayers['Fajr'] ?? DateTime.now(),
        iftar: _todayPrayers['Maghrib'] ?? DateTime.now(),
      );
      await StorageService.saveDailySchedule(schedule);
    } catch (e) {
      print('Error saving prayer times to storage: $e');
    }
  }

  /// Load prayer times from local storage (for offline access)
  Future<void> _loadPrayerTimesFromStorage() async {
    try {
      final now = DateTime.now();
      final schedule = await StorageService.getDailySchedule(now);

      if (schedule != null) {
        _todayPrayers = {};
        for (final prayer in schedule.prayers) {
          _todayPrayers[prayer.name] = prayer.calculatedTime;
        }
      }
    } catch (e) {
      print('Error loading prayer times from storage: $e');
    }
  }

  /// Update custom prayer time
  Future<void> updateCustomPrayerTime(
    String prayerName,
    DateTime customTime,
  ) async {
    try {
      // Update in-memory
      if (_todayPrayers.containsKey(prayerName)) {
        final prayer = PrayerTime(
          name: prayerName,
          date: DateTime.now(),
          calculatedTime: _todayPrayers[prayerName]!,
          customTime: customTime,
          useCustomTime: true,
          location: _location,
        );
        await StorageService.savePrayerTime(prayer);
        notifyListeners();
      }
    } catch (e) {
      _error = 'Error updating prayer time: ${e.toString()}';
      notifyListeners();
    }
  }

  /// Get next prayer name and time
  (String name, DateTime time)? getNextPrayer() {
    final now = DateTime.now();
    const prayerOrder = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

    for (final prayer in prayerOrder) {
      if (_todayPrayers.containsKey(prayer)) {
        final prayerTime = _todayPrayers[prayer]!;
        if (prayerTime.isAfter(now)) {
          return (prayer, prayerTime);
        }
      }
    }

    // Return Fajr tomorrow
    if (_tomorrowPrayers.containsKey('Fajr')) {
      return ('Fajr (Tomorrow)', _tomorrowPrayers['Fajr']!);
    }

    return null;
  }

  /// Get time until next prayer
  Duration getTimeUntilNextPrayer() {
    final next = getNextPrayer();
    if (next != null) {
      return next.$2.difference(DateTime.now());
    }
    return const Duration(hours: 24);
  }

  /// Refresh prayer times
  Future<void> refreshPrayerTimes() async {
    _lastCalculatedDate = null;
    await calculatePrayerTimes();
  }
}
