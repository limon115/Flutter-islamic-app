import 'package:hive/hive.dart';

part 'prayer_time_model.g.dart';

@HiveType(typeId: 1)
class PrayerTime extends HiveObject {
  @HiveField(0)
  String name; // Fajr, Dhuhr, Asr, Maghrib, Isha

  @HiveField(1)
  DateTime date;

  @HiveField(2)
  DateTime calculatedTime;

  @HiveField(3)
  DateTime? customTime;

  @HiveField(4)
  bool useCustomTime;

  @HiveField(5)
  String location;

  PrayerTime({
    required this.name,
    required this.date,
    required this.calculatedTime,
    this.customTime,
    this.useCustomTime = false,
    required this.location,
  });

  DateTime get displayTime => useCustomTime && customTime != null
      ? customTime!
      : calculatedTime;

  Map<String, dynamic> toJson() => {
    'name': name,
    'date': date.toIso8601String(),
    'calculatedTime': calculatedTime.toIso8601String(),
    'customTime': customTime?.toIso8601String(),
    'useCustomTime': useCustomTime,
    'location': location,
  };

  factory PrayerTime.fromJson(Map<String, dynamic> json) {
    return PrayerTime(
      name: json['name'] as String,
      date: DateTime.parse(json['date'] as String),
      calculatedTime: DateTime.parse(json['calculatedTime'] as String),
      customTime: json['customTime'] != null
          ? DateTime.parse(json['customTime'] as String)
          : null,
      useCustomTime: json['useCustomTime'] as bool? ?? false,
      location: json['location'] as String,
    );
  }

  PrayerTime copyWith({
    String? name,
    DateTime? date,
    DateTime? calculatedTime,
    DateTime? customTime,
    bool? useCustomTime,
    String? location,
  }) {
    return PrayerTime(
      name: name ?? this.name,
      date: date ?? this.date,
      calculatedTime: calculatedTime ?? this.calculatedTime,
      customTime: customTime ?? this.customTime,
      useCustomTime: useCustomTime ?? this.useCustomTime,
      location: location ?? this.location,
    );
  }
}

@HiveType(typeId: 2)
class DailyPrayerSchedule extends HiveObject {
  @HiveField(0)
  DateTime date;

  @HiveField(1)
  List<PrayerTime> prayers;

  @HiveField(2)
  String location;

  @HiveField(3)
  DateTime suhur; // Fajr time

  @HiveField(4)
  DateTime iftar; // Maghrib time

  DailyPrayerSchedule({
    required this.date,
    required this.prayers,
    required this.location,
    required this.suhur,
    required this.iftar,
  });

  Map<String, dynamic> toJson() => {
    'date': date.toIso8601String(),
    'prayers': prayers.map((p) => p.toJson()).toList(),
    'location': location,
    'suhur': suhur.toIso8601String(),
    'iftar': iftar.toIso8601String(),
  };

  factory DailyPrayerSchedule.fromJson(Map<String, dynamic> json) {
    return DailyPrayerSchedule(
      date: DateTime.parse(json['date'] as String),
      prayers: (json['prayers'] as List)
          .map((p) => PrayerTime.fromJson(p as Map<String, dynamic>))
          .toList(),
      location: json['location'] as String,
      suhur: DateTime.parse(json['suhur'] as String),
      iftar: DateTime.parse(json['iftar'] as String),
    );
  }
}
