import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/providers/prayer_time_provider.dart';
import '../../core/providers/settings_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class PrayerTimesScreen extends StatefulWidget {
  const PrayerTimesScreen({Key? key}) : super(key: key);

  @override
  State<PrayerTimesScreen> createState() => _PrayerTimesScreenState();
}

class _PrayerTimesScreenState extends State<PrayerTimesScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(
            top: 100,
            left: 16,
            right: 16,
          ),
          child: GlassCard(
            padding: EdgeInsets.zero,
            child: TabBar(
              controller: _tabController,
              indicatorColor: Theme.of(context).primaryColor,
              labelColor: Theme.of(context).primaryColor,
              unselectedLabelColor: AppTheme.textGray,
              tabs: const [
                Tab(text: 'Today'),
                Tab(text: 'Tomorrow'),
              ],
            ),
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              _PrayerTimesTab(
                prayers:
                    context.watch<PrayerTimeProvider>().todayPrayers,
              ),
              _PrayerTimesTab(
                prayers:
                    context.watch<PrayerTimeProvider>().tomorrowPrayers,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _PrayerTimesTab extends StatelessWidget {
  final Map<String, DateTime> prayers;

  const _PrayerTimesTab({
    required this.prayers,
  });

  @override
  Widget build(BuildContext context) {
    final timeFormat = context.watch<SettingsProvider>().timeFormat;

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 24,
      ),
      child: Column(
        children: prayers.entries
            .map(
              (entry) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _PrayerTimeCard(
                  prayerName: entry.key,
                  prayerTime: entry.value,
                  timeFormat: timeFormat,
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}

class _PrayerTimeCard extends StatefulWidget {
  final String prayerName;
  final DateTime prayerTime;
  final int timeFormat;

  const _PrayerTimeCard({
    required this.prayerName,
    required this.prayerTime,
    required this.timeFormat,
  });

  @override
  State<_PrayerTimeCard> createState() => _PrayerTimeCardState();
}

class _PrayerTimeCardState extends State<_PrayerTimeCard> {
  late TimeOfDay _selectedTime;
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    _selectedTime = TimeOfDay.fromDateTime(widget.prayerTime);
  }

  void _selectTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            timePickerTheme: TimePickerThemeData(
              backgroundColor: Theme.of(context).brightness ==
                      Brightness.dark
                  ? AppTheme.darkSurface
                  : Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });

      // Update the prayer time
      final newDateTime = DateTime(
        widget.prayerTime.year,
        widget.prayerTime.month,
        widget.prayerTime.day,
        picked.hour,
        picked.minute,
      );

      // ignore: use_build_context_synchronously
      context.read<PrayerTimeProvider>().updateCustomPrayerTime(
            widget.prayerName,
            newDateTime,
          );
    }
  }

  String _formatTime(TimeOfDay time) {
    final now = DateTime.now();
    final dt = DateTime(
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );

    if (widget.timeFormat == 24) {
      return DateFormat('HH:mm').format(dt);
    } else {
      return DateFormat('h:mm a').format(dt);
    }
  }

  @override
  Widget build(BuildContext context) {
    final prayerIcons = {
      'Fajr': Icons.wb_twilight,
      'Dhuhr': Icons.wb_sunny,
      'Asr': Icons.cloud,
      'Maghrib': Icons.sunset_over_water,
      'Isha': Icons.dark_mode,
    };

    return GlassCard(
      padding: const EdgeInsets.symmetric(
        vertical: 16,
        horizontal: 16,
      ),
      onTap: _isEditing ? null : () => _selectTime(),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(
                prayerIcons[widget.prayerName] ?? Icons.schedule,
                color: Theme.of(context).primaryColor,
                size: 28,
              ),
              const SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.prayerName,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Tap to edit',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _formatTime(_selectedTime),
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Theme.of(context).primaryColor,
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 4),
              Icon(
                Icons.edit,
                color: Theme.of(context).primaryColor.withOpacity(0.6),
                size: 18,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
