import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/settings_provider.dart';
import '../../core/providers/notification_provider.dart';
import '../../core/models/user_profile_model.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(
            top: 100,
            left: 16,
            right: 16,
          ),
          child: GlassCard(
            padding: EdgeInsets.zero,
            child: TabBar(
              controller: _tabController,
              isScrollable: true,
              indicatorColor: Theme.of(context).primaryColor,
              labelColor: Theme.of(context).primaryColor,
              unselectedLabelColor: AppTheme.textGray,
              tabs: const [
                Tab(text: 'Profile'),
                Tab(text: 'Appearance'),
                Tab(text: 'Notifications'),
                Tab(text: 'About'),
              ],
            ),
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              _ProfileTab(),
              _AppearanceTab(),
              _NotificationsTab(),
              _AboutTab(),
            ],
          ),
        ),
      ],
    );
  }
}

class _ProfileTab extends StatefulWidget {
  @override
  State<_ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<_ProfileTab> {
  late TextEditingController _nameController;

  @override
  void initState() {
    super.initState();
    final profile = context.read<SettingsProvider>().userProfile;
    _nameController = TextEditingController(text: profile?.name ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settingsProvider = context.watch<SettingsProvider>();

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 24,
      ),
      child: Column(
        children: [
          // Profile Image Placeholder
          GlassCard(
            padding: const EdgeInsets.all(24),
            child: Center(
              child: Column(
                children: [
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Theme.of(context)
                          .primaryColor
                          .withOpacity(0.2),
                    ),
                    child: Icon(
                      Icons.person,
                      size: 50,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                  const SizedBox(height: 16),
                  GlassPillButton(
                    onPressed: () {
                      ScaffoldMessenger.of(context)
                          .showSnackBar(
                        const SnackBar(
                          content: Text(
                              'Photo selection coming soon'),
                        ),
                      );
                    },
                    label: 'Change Photo',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Name Field
          GlassCard(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Your Name',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    hintText: 'Enter your name',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onChanged: (value) {
                    context
                        .read<SettingsProvider>()
                        .updateProfileName(value);
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Save Profile
          if (!settingsProvider.isProfileSet)
            GlassPillButton(
              onPressed: () {
                if (_nameController.text.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Please enter your name'),
                    ),
                  );
                  return;
                }

                final profile = UserProfile(
                  name: _nameController.text,
                );
                context
                    .read<SettingsProvider>()
                    .setUserProfile(profile);

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Profile saved successfully'),
                  ),
                );
              },
              label: 'Save Profile',
            ),
        ],
      ),
    );
  }
}

class _AppearanceTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final settingsProvider = context.watch<SettingsProvider>();

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 24,
      ),
      child: Column(
        children: [
          // Dark Mode Toggle
          GlassCard(
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 12,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Dark Mode',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Use dark theme',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
                Switch(
                  value: settingsProvider.isDarkMode,
                  onChanged: (value) {
                    context
                        .read<SettingsProvider>()
                        .setDarkMode(value);
                  },
                  activeColor: Theme.of(context).primaryColor,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Time Format Selection
          GlassCard(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Time Format',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                      child: GlassPillButton(
                        onPressed: () {
                          context
                              .read<SettingsProvider>()
                              .setTimeFormat(12);
                        },
                        label: '12 Hour',
                        backgroundColor:
                            settingsProvider.timeFormat == 12
                                ? Theme.of(context).primaryColor
                                : Colors.grey.withOpacity(0.3),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: GlassPillButton(
                        onPressed: () {
                          context
                              .read<SettingsProvider>()
                              .setTimeFormat(24);
                        },
                        label: '24 Hour',
                        backgroundColor:
                            settingsProvider.timeFormat == 24
                                ? Theme.of(context).primaryColor
                                : Colors.grey.withOpacity(0.3),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _NotificationsTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final notificationProvider =
        context.watch<NotificationProvider>();

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 24,
      ),
      child: Column(
        children: [
          _NotificationToggleTile(
            prayerName: 'Fajr',
            isEnabled: notificationProvider.isFajrEnabled,
            onChanged: (_) {
              context
                  .read<NotificationProvider>()
                  .toggleFajrNotification();
            },
          ),
          const SizedBox(height: 12),
          _NotificationToggleTile(
            prayerName: 'Dhuhr',
            isEnabled: notificationProvider.isDhuhrEnabled,
            onChanged: (_) {
              context
                  .read<NotificationProvider>()
                  .toggleDhuhrNotification();
            },
          ),
          const SizedBox(height: 12),
          _NotificationToggleTile(
            prayerName: 'Asr',
            isEnabled: notificationProvider.isAsrEnabled,
            onChanged: (_) {
              context
                  .read<NotificationProvider>()
                  .toggleAsrNotification();
            },
          ),
          const SizedBox(height: 12),
          _NotificationToggleTile(
            prayerName: 'Maghrib',
            isEnabled: notificationProvider.isMaghribEnabled,
            onChanged: (_) {
              context
                  .read<NotificationProvider>()
                  .toggleMaghribNotification();
            },
          ),
          const SizedBox(height: 12),
          _NotificationToggleTile(
            prayerName: 'Isha',
            isEnabled: notificationProvider.isIshaEnabled,
            onChanged: (_) {
              context
                  .read<NotificationProvider>()
                  .toggleIshaNotification();
            },
          ),
        ],
      ),
    );
  }
}

class _NotificationToggleTile extends StatelessWidget {
  final String prayerName;
  final bool isEnabled;
  final ValueChanged<bool> onChanged;

  const _NotificationToggleTile({
    required this.prayerName,
    required this.isEnabled,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 12,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$prayerName Notification',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 4),
              Text(
                'Notify at prayer time',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
          Switch(
            value: isEnabled,
            onChanged: onChanged,
            activeColor: Theme.of(context).primaryColor,
          ),
        ],
      ),
    );
  }
}

class _AboutTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 24,
      ),
      child: Column(
        children: [
          GlassCard(
            padding: const EdgeInsets.all(24),
            child: Center(
              child: Column(
                children: [
                  Icon(
                    Icons.mosque,
                    size: 64,
                    color: Theme.of(context).primaryColor,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Islamic Prayer Times',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Version 1.0.0',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          GlassCard(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'About',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 12),
                Text(
                  'Islamic Prayer Times provides accurate prayer times for Bangladesh based on astronomical calculations using the Muslim World League method.',
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                const SizedBox(height: 16),
                Text(
                  'Features',
                  style: Theme.of(context)
                      .textTheme
                      .titleLarge
                      ?.copyWith(
                        color: Theme.of(context).primaryColor,
                      ),
                ),
                const SizedBox(height: 12),
                Text(
                  '• Accurate prayer times based on GPS location\n• Offline functionality\n• Customizable prayer notifications\n• Glassmorphism UI design\n• Dark mode support\n• Multiple time format options',
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          GlassCard(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Developer',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 12),
                Text(
                  'Created with ❤️ for the Muslim community in Bangladesh',
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                const SizedBox(height: 12),
                Text(
                  'Contact: dev@islamicprayertimes.com',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
