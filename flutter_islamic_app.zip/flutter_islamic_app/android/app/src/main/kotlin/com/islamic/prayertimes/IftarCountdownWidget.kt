package com.islamic.prayertimes

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.SharedPreferences
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.*

class IftarCountdownWidget : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    companion object {
        fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val views = RemoteViews(
                context.packageName,
                R.layout.widget_iftar_countdown
            )

            // Get Iftar time from SharedPreferences
            val prefs: SharedPreferences =
                context.getSharedPreferences("islamic_prayer_times", Context.MODE_PRIVATE)
            val iftarTimeString = prefs.getString("iftar_time", "") ?: ""

            if (iftarTimeString.isNotEmpty()) {
                try {
                    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    val iftarTime = sdf.parse(iftarTimeString) ?: return
                    val now = Calendar.getInstance().time

                    val diffMillis = iftarTime.time - now.time
                    if (diffMillis > 0) {
                        val hours = (diffMillis / (1000 * 60 * 60)) % 24
                        val minutes = (diffMillis / (1000 * 60)) % 60
                        val seconds = (diffMillis / 1000) % 60

                        val countdownText = String.format(
                            "%02d:%02d:%02d",
                            hours,
                            minutes,
                            seconds
                        )

                        views.setTextViewText(
                            R.id.widget_countdown,
                            countdownText
                        )
                        views.setTextViewText(
                            R.id.widget_label,
                            "Time to Iftar"
                        )
                    } else {
                        views.setTextViewText(
                            R.id.widget_countdown,
                            "00:00:00"
                        )
                        views.setTextViewText(
                            R.id.widget_label,
                            "Iftar Passed"
                        )
                    }
                } catch (e: Exception) {
                    views.setTextViewText(
                        R.id.widget_countdown,
                        "Loading..."
                    )
                }
            } else {
                views.setTextViewText(
                    R.id.widget_countdown,
                    "Loading..."
                )
            }

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
