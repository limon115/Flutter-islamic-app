# Islamic Prayer Times - Complete Implementation Guide

## 🎯 Project Overview

A production-ready Flutter application for Bangladesh that displays accurate Suhur (Fajr), Iftar (Maghrib), and five daily Namaz times based on the user's GPS location. Features glassmorphism UI, offline capability, and Android home screen widget.

---

## 📋 Prerequisites

### For Building on PC (Optional)
- Flutter SDK 3.16.0 or later
- Android SDK 21+
- Java JDK 11+
- Git

### For Building Without PC (Using GitHub Actions)
- GitHub account
- Repository access
- No local setup required!

---

## 🚀 Quick Start (No PC Required - GitHub Actions)

### Step 1: Clone Repository
```bash
git clone <your-repo-url>
cd flutter_islamic_app
```

### Step 2: Push to GitHub
```bash
git add .
git commit -m "Initial commit"
git push origin main
```

### Step 3: GitHub Actions Builds Automatically
- Go to **Actions** tab in your GitHub repository
- Workflow `Build APK Release` runs automatically on every push to `main`
- Wait for build to complete (5-10 minutes)

### Step 4: Download APK
1. Click on the completed workflow run
2. Scroll down to **Artifacts**
3. Download `release-apk` (contains `app-release.apk`)
4. Transfer APK to your Android phone (use browser, email, or messaging app)

### Step 5: Install on Phone
1. Open file manager on Android phone
2. Navigate to Downloads folder
3. Long-press `app-release.apk`
4. Tap "Install"
5. Grant permissions:
   - Location access (for GPS)
   - Notifications (for prayer reminders)

---

## 💻 Local Build Instructions (If You Have a PC)

### Step 1: Setup Flutter Environment
```bash
flutter --version  # Should be 3.16.0+
flutter doctor     # Check all dependencies
```

### Step 2: Clone and Setup Project
```bash
git clone <your-repo-url>
cd flutter_islamic_app

# Get dependencies
flutter pub get

# Generate code (Hive adapters)
flutter pub run build_runner build --delete-conflicting-outputs
```

### Step 3: Build APK
```bash
# Debug APK (for testing)
flutter build apk --debug

# Release APK (for production)
flutter build apk --release

# Split APKs by architecture (smaller file size)
flutter build apk --target-platform android-arm64 --split-per-abi --release
```

### Step 4: Locate APK
- Release APK: `build/app/outputs/flutter-apk/app-release.apk`
- Debug APK: `build/app/outputs/flutter-apk/app-debug.apk`

### Step 5: Install on Device
```bash
# Via USB
flutter install

# Or transfer APK manually to phone
adb install build/app/outputs/flutter-apk/app-release.apk
```

---

## 📁 Project Structure

```
flutter_islamic_app/
├── lib/
│   ├── main.dart                              # App entry point
│   ├── core/
│   │   ├── models/
│   │   │   ├── user_profile_model.dart       # Hive model
│   │   │   ├── user_profile_model.g.dart     # Generated adapter
│   │   │   ├── prayer_time_model.dart        # Hive model
│   │   │   └── prayer_time_model.g.dart      # Generated adapter
│   │   ├── providers/
│   │   │   ├── location_provider.dart         # Location state
│   │   │   ├── prayer_time_provider.dart      # Prayer times state
│   │   │   ├── settings_provider.dart         # Settings state
│   │   │   └── notification_provider.dart     # Notifications state
│   │   └── services/
│   │       ├── location_service.dart          # GPS & geocoding
│   │       ├── prayer_time_service.dart       # Astronomical calculations
│   │       ├── notification_service.dart      # Local notifications
│   │       └── storage_service.dart           # Local database
│   └── ui/
│       ├── theme/
│       │   └── app_theme.dart                 # Glassmorphism theme
│       ├── widgets/
│       │   ├── glass_card.dart                # Custom glass widgets
│       │   └── countdown_timer.dart           # Countdown timer
│       └── screens/
│           ├── home_screen.dart               # Main navigation
│           ├── dashboard_screen.dart          # Iftar countdown
│           ├── prayer_times_screen.dart       # Prayer times display
│           └── settings_screen.dart           # Settings & profile
├── android/
│   ├── app/
│   │   ├── build.gradle                       # Gradle build
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml            # Permissions
│   │   │   ├── kotlin/
│   │   │   │   └── IftarCountdownWidget.kt    # Widget code
│   │   │   ├── res/
│   │   │   │   ├── layout/
│   │   │   │   │   └── widget_iftar_countdown.xml
│   │   │   │   ├── drawable/
│   │   │   │   │   └── widget_bg.xml
│   │   │   │   ├── values/
│   │   │   │   │   └── colors.xml
│   │   │   │   └── xml/
│   │   │   │       └── widget_info.xml
├── .github/
│   └── workflows/
│       └── build_apk.yml                      # GitHub Actions CI/CD
└── pubspec.yaml                               # Dependencies
```

---

## 📦 Key Dependencies

### Location & Mapping
- `geolocator: ^11.0.0` - GPS location services
- `geocoding: ^2.1.1` - Reverse geocoding

### Prayer Times (Astronomical Calculation)
- `adhan: ^2.0.0` - Islamic prayer time calculations (Muslim World League method)

### State Management
- `provider: ^6.1.0` - State management

### Local Storage
- `hive: ^2.2.3` - NoSQL local database
- `hive_flutter: ^1.1.0` - Flutter integration

### Notifications
- `flutter_local_notifications: ^16.3.0` - Local notifications
- `timezone: ^0.9.2` - Timezone support

### UI & Theme
- `glassmorphism: ^3.0.0` - Glassmorphism effects
- `intl: ^0.19.0` - Date/time formatting

### Home Widget
- `home_widget: ^0.4.0` - Android home screen widget

### Permissions
- `permission_handler: ^11.4.4` - Runtime permissions

---

## 🔑 Key Features Explained

### 1. **Astronomical Prayer Time Calculations**
- Uses **Adhan** package with **Muslim World League** method
- Fajr angle: 18°, Isha angle: 17°
- Automatically adjusts for **Asia/Dhaka** timezone
- Works offline after first calculation

### 2. **GPS Location**
- Requests fine GPS location from device
- Falls back to last known location if unavailable
- Reverse geocodes to human-readable place name

### 3. **Glassmorphism UI**
- Custom glass card components
- Backdrop blur effects
- Pale green Islamic color palette (#27AE60)
- Smooth animations and transitions
- One UI-like rounded corners

### 4. **Local Data Persistence**
- Profile data saved locally
- Custom prayer times saved
- Settings persist across app restarts
- Old schedules cleaned up automatically

### 5. **Notifications**
- Local push notifications (no internet required)
- Can be toggled per prayer
- Runs in background

### 6. **Android Home Widget**
- Shows Iftar countdown
- Updates every minute
- Glassmorphism design
- Pill-shaped with rounded corners

---

## 🛠️ Configuration

### Permissions (AndroidManifest.xml)
```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

### Prayer Time Settings
Edit `PrayerTimeService.dart` to change calculation method:
```dart
static const CalculationMethod calculationMethod =
    CalculationMethod.MuslimWorldLeague;
```

### Time Zone
The app automatically uses **Asia/Dhaka** timezone:
```dart
tz.getLocation('Asia/Dhaka')
```

---

## 🐛 Troubleshooting

### Build Issues

**Error: "Flutter not found"**
```bash
flutter pub get
flutter pub run build_runner build --delete-conflicting-outputs
```

**Error: "Hive adapters not generated"**
```bash
flutter pub run build_runner clean
flutter pub run build_runner build --delete-conflicting-outputs
```

**Error: "Location permission denied"**
- App requests permission on first launch
- Go to **Settings > Apps > Islamic Prayer Times > Permissions** to grant

### Runtime Issues

**Prayer times show as "Loading..."**
- Check internet connection (first time)
- Ensure location permission is granted
- Restart the app

**Iftar countdown not updating**
- Ensure time system on phone is correct
- Check if background processes are not restricted
- Reinstall if needed

**Notifications not working**
- Go to **Settings > Apps > Islamic Prayer Times > Notifications** and enable
- Check system notification settings
- Verify alarm is on in device settings

---

## 📱 Testing

### On Emulator
```bash
flutter emulators
flutter emulators launch <emulator_id>
flutter run
```

### On Physical Device
```bash
# USB debugging must be enabled
adb devices
flutter install
flutter run
```

### Testing Features

**Location Testing**
- Use mock location app from Play Store
- Or enable developer mock location in Settings

**Notifications**
- Set test time close to current time
- Check notification log in device Settings

**Offline Mode**
- Calculate once with internet
- Disable internet and restart app
- Prayer times should still load from cache

---

## 📊 Performance Considerations

### Battery Optimization
- Prayer time calculations are cached
- Countdown timer updates every second (minimal drain)
- Widget updates every minute
- Location refresh only on app open or manual

### Memory Usage
- ~50MB app size (release)
- Minimal RAM footprint (~100MB)
- Efficient stream management
- Automatic cleanup of old data

### Network Usage
- First launch: ~1MB (location reverse geocoding)
- Updates: <1KB (only if location changes)
- No background sync

---

## 🔐 Security & Privacy

### Location Data
- Only stored locally on device
- Never sent to external servers
- Can be cleared in Settings

### Personal Data
- Profile information stored locally only
- No cloud synchronization
- Users can delete data anytime

### Permissions
- Only requests necessary permissions
- Location used only for prayer calculations
- Notifications fully user-controlled

---

## 📈 Future Enhancements

Possible improvements for v2.0:
- [ ] Support for other calculation methods (Isna, AlAzhar, etc.)
- [ ] Monthly/yearly prayer schedules
- [ ] Prayer event calendar
- [ ] Multiple location support
- [ ] Prayer maturity tracker
- [ ] Family/group sharing
- [ ] Qibla direction compass
- [ ] Prayer time graph visualization

---

## 👨‍💻 Developer Info

**Created for:** Islamic community in Bangladesh  
**Version:** 1.0.0  
**Flutter Version:** 3.16.0+  
**Min Android SDK:** 21  
**Target Android SDK:** 34  

**Contact:** dev@islamicprayertimes.com

---

## 📜 License

This project is provided as-is for educational and religious purposes.

---

## 🤝 Contributing

To contribute:
1. Fork the repository
2. Create feature branch
3. Make changes
4. Submit pull request

---

## ✅ Checklist for First Use

- [ ] Grant location permission on first launch
- [ ] Grant notification permission
- [ ] Verify prayer times are correct for your location
- [ ] Test Iftar countdown
- [ ] Enable dark mode if desired
- [ ] Set custom prayer times if needed
- [ ] Enable prayer notifications
- [ ] Add widget to home screen

---

## 📞 Support

**Issues with app?**
- Check GitHub Issues
- Verify Android version (21+)
- Ensure location is enabled
- Clear app cache: Settings > Apps > Islamic Prayer Times > Storage > Clear Cache

**Issues with prayer times?**
- Verify GPS location is accurate
- Check if calculation method is correct
- Ensure device time is correct
- Check timezone is set to Asia/Dhaka

---

## 🙏 Acknowledgments

- **Adhan** package for accurate prayer time calculations
- **Flutter** team for amazing framework
- **Bangladesh Islamic community** for inspiration

---

**Alhamdulillah - All praise is due to Allah**

May this app help you maintain your daily prayers and spiritual connection. ✨🕌
