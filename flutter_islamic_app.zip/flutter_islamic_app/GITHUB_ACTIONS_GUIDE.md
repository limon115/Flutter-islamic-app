# 🚀 Build APK Without PC - GitHub Actions Complete Guide

This guide shows you how to build the Islamic Prayer Times app and download it to your phone **without needing a PC or laptop**.

---

## 📋 What You Need

- ✅ GitHub account (free)
- ✅ This repository
- ✅ Android phone with browser
- ✅ USB cable to transfer files (or use email/messaging)

---

## 🎯 Step-by-Step Instructions

### STEP 1: Create GitHub Account (If You Don't Have One)

1. Go to **https://github.com/signup**
2. Enter email and create password
3. Verify your email
4. Done! ✅

### STEP 2: Fork This Repository

1. Go to this repository (if not already there)
2. Click **Fork** button (top right)
3. Name it: `islamic-prayer-times` (or anything)
4. Click **Create fork**

You now have a copy of the code on your GitHub account! 📋

### STEP 3: Enable GitHub Actions

1. Go to your forked repository
2. Click **Settings** tab
3. On left side, click **Actions > General**
4. Under "Actions permissions", select **Allow all actions**
5. Scroll down and click **Save**

GitHub Actions is now enabled! 🔧

### STEP 4: Trigger the Build

1. Go to your repository main page
2. Click **Actions** tab
3. Click **Build APK Release** workflow on the left
4. Click **Run workflow** (white dropdown button on right)
5. Select **main** branch
6. Click **Run workflow** green button

The build will start automatically! ⚡

### STEP 5: Monitor Build Progress

1. Stay on the **Actions** page
2. You'll see a yellow circle (building) next to your workflow
3. Wait 5-10 minutes for it to complete
4. When done, circle turns **green** ✅

**The build takes about:**
- 2-3 minutes: Setup
- 3-5 minutes: Build
- 1-2 minutes: Upload

Total: ~7-10 minutes ⏱️

### STEP 6: Download the APK

1. Click on the **workflow run** (green checkmark)
2. Scroll down to **Artifacts** section
3. You'll see **release-apk** (the file you want!)
4. Click to download `app-release.apk`
5. Also download `release-notes` to see installation instructions

**File size:** ~50-60 MB

### STEP 7: Transfer APK to Phone

**Option A: Email**
1. From your PC, email the APK to yourself
2. Open Gmail on phone
3. Download the attachment
4. Proceed to Step 8

**Option B: Google Drive/OneDrive**
1. Upload APK to cloud storage
2. Access from phone
3. Download
4. Proceed to Step 8

**Option C: USB Cable** (Recommended)
1. Connect phone to PC with USB cable
2. Enable USB file transfer in phone notifications
3. Copy APK to phone's **Downloads** folder
4. Proceed to Step 8

**Option D: Direct Download**
1. Open GitHub on phone browser
2. Go to Actions tab
3. Click completed workflow
4. Download artifact
5. Proceed to Step 8

### STEP 8: Install APK on Phone

**On Your Android Phone:**

1. Open **Files** / **File Manager** app
2. Navigate to **Downloads** folder
3. Find `app-release.apk`
4. **Long-press** the file
5. Tap **Open** or **Install**
6. If prompted: **Settings > Unknown sources > Allow**
7. Tap **Install**
8. Wait for installation to complete
9. Tap **Open** to launch app

**Installation takes:** 30 seconds - 1 minute ⏱️

### STEP 9: First Launch - Grant Permissions

When you open the app for the first time:

1. ✅ **Allow Location Access**
   - Tap **Allow** or **Allow all the time**
   - This is required for prayer times
   - Permission is only used locally on your device

2. ✅ **Allow Notifications**
   - Tap **Allow**
   - This enables prayer time reminders

3. ✅ **Create Profile**
   - Enter your name
   - Tap **Save Profile**

Done! The app will now calculate prayer times for your location! 🕌

---

## 🔄 Rebuilding After Changes

To rebuild the app after you make code changes:

1. Go to **Actions** tab
2. Click **Build APK Release** workflow
3. Click **Run workflow** 
4. Select your branch
5. Click **Run workflow**

The build starts again! No need to learn anything else.

---

## 📲 Using the App

### Main Dashboard
- Shows **Iftar countdown** (time until Maghrib/sunset)
- Shows today's **Suhur** and **Iftar** times
- Live updating countdown timer

### Prayer Times
- View all 5 daily prayers (Fajr, Dhuhr, Asr, Maghrib, Isha)
- Tap any prayer to customize the time
- Defaults use astronomical calculations

### Settings
1. **Profile** - Add your name and photo
2. **Appearance** - Dark mode & time format (12/24 hour)
3. **Notifications** - Toggle alerts for each prayer
4. **About** - App info and features

### Home Widget (Optional)
1. Long-press home screen
2. Tap **Widgets**
3. Search for **Islamic Prayer Times**
4. Drag widget to home screen
5. Resizes automatically

---

## ✅ Troubleshooting

### APK Won't Install
**Error: "Parse error"**
- Download again (file may be corrupted)
- Use USB cable instead of email

**Error: "Unknown sources disabled"**
- Settings > Apps > Allow installation from unknown sources
- Search for your downloader app
- Enable "Install unknown apps"

### App Won't Open
**Error: "Unfortunately stopped"**
- Clear app data: Settings > Apps > Islamic Prayer Times > Storage > Clear Data
- Reinstall APK
- Restart phone

### Prayer Times Show "Loading..."
- Ensure location is enabled
- Ensure internet is on (first time only)
- Grant location permission
- Wait 30 seconds
- Restart app

### Notifications Not Working
- Go to Settings > Apps > Islamic Prayer Times
- Tap **Notifications**
- Enable **All notifications**
- Disable **Do not disturb** or set exceptions

### Widget Not Updating
- Home widget updates every minute
- Give it a moment to update
- Restart phone if stuck

---

## 🎨 Customization

You can modify the code and rebuild!

**To change colors:**
- Edit `lib/ui/theme/app_theme.dart`
- Change `primaryGreen = Color(0xFF27AE60)` to any hex color
- Push to GitHub
- Rebuild via Actions

**To change notification time:**
- Edit `lib/core/services/notification_service.dart`
- Modify timing logic
- Push and rebuild

**To change app name:**
- Edit `lib/main.dart` line with `'Islamic Prayer Times'`
- Change in `pubspec.yaml`
- Rebuild

---

## 📊 Build Logs

To see detailed build logs:

1. Go to **Actions** tab
2. Click on your workflow run
3. Click **build** job
4. Expand steps to see logs
5. Look for errors (red text)

Common messages:
- 🟡 Yellow = Warning (usually OK)
- 🔴 Red = Error (need to fix)
- ✅ Green = Success

---

## 💾 Keeping It Updated

Every time you push code changes:

```bash
git add .
git commit -m "Update: your changes here"
git push origin main
```

GitHub Actions automatically:
1. Detects the push
2. Builds a new APK
3. Saves it as artifact
4. Ready to download!

---

## 🔐 Security Note

The APK you build:
- Is built from **your code** (open source)
- Never touches external servers
- Only runs on **your device**
- Stores data **locally** on phone
- Doesn't share location with anyone

You can verify the code before building:
1. Go to Code tab
2. View all files
3. See exactly what's in the app

---

## 📱 System Requirements

**Minimum:**
- Android 5.0+ (API 21)
- 50 MB storage
- 2GB RAM

**Recommended:**
- Android 10+ (API 29)
- 100+ MB storage
- 4GB+ RAM

**Tested On:**
- Pixel 4a (Android 12)
- Samsung Galaxy A12 (Android 11)
- OnePlus 8 (Android 13)
- Redmi Note 10 (Android 12)

---

## 🚀 Advanced: Custom Domain Build

Want to build under your own app name?

Edit `android/app/build.gradle`:
```gradle
applicationId "com.yourname.prayertimes"
```

Edit `AndroidManifest.xml`:
```xml
<activity
    android:name=".MainActivity"
    android:label="My Prayer App"
```

Then rebuild via GitHub Actions!

---

## 📞 Getting Help

**If something goes wrong:**

1. Check this guide again (you might have missed a step)
2. Check **Troubleshooting** section above
3. Review build logs in Actions
4. Check GitHub Issues on the repository
5. Contact: dev@islamicprayertimes.com

---

## 🎉 You Did It!

Congratulations! 🎊

You just built a professional Android app **without coding knowledge**! 

Your app can now:
✅ Calculate accurate prayer times  
✅ Show Iftar countdown  
✅ Send notifications  
✅ Work offline  
✅ Show beautiful glassmorphism UI  

Alhamdulillah! 🕌

---

## 📚 Next Steps

1. **Tell friends & family** about your app
2. **Customize** the colors or features
3. **Share code** on GitHub
4. **Submit to Play Store** (advanced)
5. **Keep it updated** with new features

---

## 💡 Tips & Tricks

**Make builds faster:**
- Small code changes build quicker
- Push during off-hours for shorter queue
- GitHub free tier gets ~2000 minutes/month

**Multiple versions:**
- Create different branches (e.g., `dev`, `release`)
- Each branch can have separate build workflows
- Test new features before merging

**Track changes:**
- Each GitHub commit is tracked
- Can revert to old versions anytime
- Version control built-in

---

**Happy coding! May your app help people stay connected to their faith.** ✨🕌

أدام الله عليكم الخير - May Allah keep you in goodness.
