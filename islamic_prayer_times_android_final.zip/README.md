# Islamic Prayer Times — Bangladesh 🕌

A production-grade Native Android app (Java + XML) providing precise Suhur, Iftar, and Namaz times based on GPS location.

**Developer:** Khalid Hasan Limon | Student Developer | Bangladesh

## Features
- 📍 GPS-based prayer times (Karachi method, Hanafi Asr)
- ⏱️ Live Iftar/Suhur countdown (HH:MM:SS)
- 🔔 Per-prayer notifications with AlarmManager
- 🏠 Home screen glassmorphism widget
- 🌓 Dark/Light mode
- 💾 Fully offline after first GPS fix

## Build Instructions

### Prerequisites
- Android Studio Hedgehog or newer
- JDK 17
- Android SDK 34

### ⚠️ Important: Gradle Wrapper JAR

The `gradle/wrapper/gradle-wrapper.jar` included is a stub. Before building, run:

```bash
# Option 1: Let Gradle self-bootstrap (recommended)
./gradlew wrapper --gradle-version=8.4 --distribution-type=bin

# Option 2: Download manually
curl -L https://services.gradle.org/distributions/gradle-8.4-bin.zip -o /tmp/gradle.zip
unzip -p /tmp/gradle.zip gradle-8.4/lib/plugins/gradle-wrapper-*.jar > gradle/wrapper/gradle-wrapper.jar
```

### Build

```bash
./gradlew assembleRelease
```

APK output: `app/build/outputs/apk/release/`

## CI/CD

Push to GitHub and use `.github/workflows/build_apk.yml` — it handles the wrapper JAR download automatically.
