package com.khalid.islamicprayertimes.receivers;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

import com.khalid.islamicprayertimes.R;
import com.khalid.islamicprayertimes.activities.MainActivity;
import com.khalid.islamicprayertimes.utils.NotificationHelper;

public class PrayerNotificationReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String prayerName = intent.getStringExtra(NotificationHelper.EXTRA_PRAYER_NAME);
        if (prayerName == null) prayerName = "Prayer";

        Intent mainIntent = new Intent(context, MainActivity.class);
        mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, mainIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String title = prayerName + " Time";
        String message = "It's time for " + prayerName + " prayer. Allahu Akbar!";

        // Special messages for Suhur/Iftar
        if (prayerName.equals("Fajr")) {
            title = "Suhur & Fajr Time";
            message = "Time for Suhur is ending. Fajr prayer time has begun.";
        } else if (prayerName.equals("Maghrib")) {
            title = "Iftar & Maghrib Time";
            message = "Iftar time! Break your fast. Maghrib prayer time has begun.";
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, NotificationHelper.CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_mosque)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setVibrate(new long[]{0, 500, 200, 500});

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify((int) System.currentTimeMillis(), builder.build());
        }
    }
}
