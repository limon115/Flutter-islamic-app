package com.khalid.islamicprayertimes.utils;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * Precise astronomical prayer time calculator.
 * Implements the algorithm from "Astronomical Algorithms" by Jean Meeus
 * and the PrayTimes.org method for Bangladesh.
 */
public class PrayerTimesCalculator {

    // Calculation Methods
    public static final int METHOD_KARACHI = 1;       // University of Islamic Sciences, Karachi
    public static final int METHOD_ISNA = 2;          // Islamic Society of North America
    public static final int METHOD_MWL = 3;           // Muslim World League
    public static final int METHOD_MAKKAH = 4;        // Umm Al-Qura University, Makkah
    public static final int METHOD_EGYPT = 5;         // Egyptian General Authority of Survey
    public static final int METHOD_TEHRAN = 6;        // Institute of Geophysics, Tehran
    public static final int METHOD_JAFARI = 7;        // Shia Ithna-Ashari

    // Asr Juristic Methods
    public static final int ASR_SHAFII = 1;
    public static final int ASR_HANAFI = 2;

    // High Latitude Methods
    public static final int HIGH_LAT_NONE = 0;
    public static final int HIGH_LAT_NIGHT_MIDDLE = 1;
    public static final int HIGH_LAT_ONE_SEVENTH = 2;
    public static final int HIGH_LAT_ANGLE_BASED = 3;

    // Time formats
    public static final int TIME_24H = 0;
    public static final int TIME_12H = 1;

    // Prayer times index
    public static final int FAJR = 0;
    public static final int SUNRISE = 1;
    public static final int DHUHR = 2;
    public static final int ASR = 3;
    public static final int SUNSET = 4;
    public static final int MAGHRIB = 5;
    public static final int ISHA = 6;

    private double latitude;
    private double longitude;
    private double elevation = 0;
    private int calcMethod = METHOD_KARACHI; // Bangladesh uses Karachi method
    private int asrJuristic = ASR_HANAFI;   // Bangladesh commonly uses Hanafi
    private int highLatMethod = HIGH_LAT_ANGLE_BASED;
    private double dhuhrMinutes = 0;

    // Method-specific parameters: {fajrAngle, maghribIsMinutes, maghribValue, ishaIsMinutes, ishaValue}
    private final double[][] methodParams = {
            {0, 0, 0, 0, 0},         // [0] Leva Research Institute, Qum
            {18, 1, 0, 0, 18},       // [1] Karachi
            {15, 0, 0, 0, 15},       // [2] ISNA
            {18, 0, 0, 0, 17},       // [3] MWL
            {18.5, 1, 90, 0, 0},     // [4] Makkah
            {19.5, 0, 0, 0, 17.5},   // [5] Egypt
            {17.7, 0, 4.5, 0, 14},   // [6] Tehran
            {16, 0, 4, 0, 14},       // [7] Jafari
    };

    // Tuning offsets in minutes
    private final double[] offsets = {0, 0, 0, 0, 0, 0, 0};

    // Julian date
    private double JDate;

    public PrayerTimesCalculator(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public PrayerTimesCalculator(double latitude, double longitude, double elevation) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.elevation = elevation;
    }

    // ---------- Public API ----------

    /**
     * Returns prayer times as double[] in fractional hours (0-24).
     * Index: 0=Fajr, 1=Sunrise, 2=Dhuhr, 3=Asr, 4=Sunset, 5=Maghrib, 6=Isha
     */
    public double[] getPrayerTimesDouble(int year, int month, int day) {
        JDate = julianDate(year, month, day) - longitude / (15.0 * 24.0);
        return computeTimes();
    }

    /**
     * Returns prayer times as String array formatted per timeFormat.
     */
    public String[] getPrayerTimesFormatted(int year, int month, int day, int timeFormat) {
        double[] times = getPrayerTimesDouble(year, month, day);
        String[] result = new String[7];
        String[] names = {"Fajr", "Sunrise", "Dhuhr", "Asr", "Sunset", "Maghrib", "Isha"};
        for (int i = 0; i < 7; i++) {
            result[i] = formatTime(times[i], timeFormat);
        }
        return result;
    }

    public void setCalcMethod(int method) {
        this.calcMethod = method;
    }

    public void setAsrJuristic(int method) {
        this.asrJuristic = method;
    }

    public void setHighLatMethod(int method) {
        this.highLatMethod = method;
    }

    // ---------- Core Calculation ----------

    private double[] computeTimes() {
        // Default times (in fractional hours)
        double[] times = {5, 6, 12, 13, 18, 18, 18};

        // Iterative computation for accuracy
        for (int i = 0; i < 1; i++) {
            times = computePrayerTimes(times);
        }
        times = adjustTimes(times);
        times = tuneTimes(times);
        return times;
    }

    private double[] computePrayerTimes(double[] times) {
        double[] t = dayPortion(times);
        double fajr = sunAngleTime(methodParams[calcMethod][0], t[FAJR], true);
        double sunrise = sunAngleTime(riseSetAngle(), t[SUNRISE], true);
        double dhuhr = midDay(t[DHUHR]);
        double asr = asrTime(asrJuristic, t[ASR]);
        double sunset = sunAngleTime(riseSetAngle(), t[SUNSET], false);
        double maghrib = sunAngleTime(methodParams[calcMethod][2], t[MAGHRIB], false);
        double isha = sunAngleTime(methodParams[calcMethod][4], t[ISHA], false);

        // Maghrib and Isha: if isMinutes, add to sunset
        if (methodParams[calcMethod][1] == 1) {
            maghrib = sunset + methodParams[calcMethod][2] / 60.0;
        }
        if (methodParams[calcMethod][3] == 1) {
            isha = maghrib + methodParams[calcMethod][4] / 60.0;
        }

        return new double[]{fajr, sunrise, dhuhr, asr, sunset, maghrib, isha};
    }

    // ---------- Sun Calculations ----------

    private double julianDate(int year, int month, int day) {
        if (month <= 2) {
            year -= 1;
            month += 12;
        }
        double A = Math.floor(year / 100.0);
        double B = 2 - A + Math.floor(A / 4.0);
        return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + B - 1524.5;
    }

    private double sunPosition(double jd) {
        double D = jd - 2451545.0;
        double g = fixAngle(357.529 + 0.98560028 * D);
        double q = fixAngle(280.459 + 0.98564736 * D);
        double L = fixAngle(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g));
        double e = 23.439 - 0.00000036 * D;
        double RA = datan2(dcos(e) * dsin(L), dcos(L)) / 15.0;
        RA = RA - Math.floor(RA / 24.0) * 24;
        double eqt = q / 15.0 - RA;
        double decl = dasin(dsin(e) * dsin(L));
        return decl; // We return only declination; eqt used separately
    }

    private double equationOfTime(double jd) {
        double D = jd - 2451545.0;
        double g = fixAngle(357.529 + 0.98560028 * D);
        double q = fixAngle(280.459 + 0.98564736 * D);
        double L = fixAngle(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g));
        double e = 23.439 - 0.00000036 * D;
        double RA = datan2(dcos(e) * dsin(L), dcos(L)) / 15.0;
        RA = RA - Math.floor(RA / 24.0) * 24;
        return q / 15.0 - RA;
    }

    private double sunDeclination(double jd) {
        double D = jd - 2451545.0;
        double g = fixAngle(357.529 + 0.98560028 * D);
        double L = fixAngle(280.459 + 0.98564736 * D + 1.915 * dsin(g) + 0.020 * dsin(2 * g));
        double e = 23.439 - 0.00000036 * D;
        return dasin(dsin(e) * dsin(L));
    }

    private double midDay(double t) {
        double eqt = equationOfTime(JDate + t);
        return fixHour(12 - eqt);
    }

    private double sunAngleTime(double angle, double t, boolean ccw) {
        double decl = sunDeclination(JDate + t);
        double noon = midDay(t);
        double cosVal = (-dsin(angle) - dsin(decl) * dsin(latitude)) / (dcos(decl) * dcos(latitude));
        cosVal = Math.min(1, Math.max(-1, cosVal));
        double ha = dacos(cosVal) / 15.0;
        return noon + (ccw ? -ha : ha);
    }

    private double asrTime(int shadow, double t) {
        double decl = sunDeclination(JDate + t);
        double angle = -datan(1.0 / (shadow + dtan(Math.abs(latitude - decl))));
        return sunAngleTime(angle, t, false);
    }

    private double riseSetAngle() {
        // 0.833 degrees for atmospheric refraction, 0.0347 * sqrt(elevation) for elevation
        return 0.833 + 0.0347 * Math.sqrt(elevation);
    }

    // ---------- Adjust Times ----------

    private double[] adjustTimes(double[] times) {
        for (int i = 0; i < 7; i++) {
            times[i] += longitude / 15.0 - longitude / 15.0;
            // Already accounted for in JDate offset, apply timezone
            // Bangladesh is UTC+6
            times[i] += 6.0 - longitude / 15.0;
        }
        times[DHUHR] += dhuhrMinutes / 60.0;
        if (methodParams[calcMethod][1] == 1) {
            times[MAGHRIB] = times[SUNSET] + methodParams[calcMethod][2] / 60.0;
        }
        if (methodParams[calcMethod][3] == 1) {
            times[ISHA] = times[MAGHRIB] + methodParams[calcMethod][4] / 60.0;
        }
        if (highLatMethod != HIGH_LAT_NONE) {
            times = adjustHighLatTimes(times);
        }
        return times;
    }

    private double[] adjustHighLatTimes(double[] times) {
        double nightTime = timeDiff(times[SUNSET], times[SUNRISE]);
        double fajrDiff = nightPortion(methodParams[calcMethod][0]) * nightTime;
        double ishaDiff = nightPortion(methodParams[calcMethod][4]) * nightTime;
        if (Double.isNaN(times[FAJR]) || timeDiff(times[FAJR], times[SUNRISE]) > fajrDiff) {
            times[FAJR] = times[SUNRISE] - fajrDiff;
        }
        if (Double.isNaN(times[ISHA]) || timeDiff(times[SUNSET], times[ISHA]) > ishaDiff) {
            times[ISHA] = times[SUNSET] + ishaDiff;
        }
        if (methodParams[calcMethod][1] != 1 && (Double.isNaN(times[MAGHRIB]) || timeDiff(times[SUNSET], times[MAGHRIB]) > ishaDiff)) {
            times[MAGHRIB] = times[SUNSET] + nightPortion(methodParams[calcMethod][2]) * nightTime;
        }
        return times;
    }

    private double nightPortion(double angle) {
        switch (highLatMethod) {
            case HIGH_LAT_ANGLE_BASED: return angle / 60.0;
            case HIGH_LAT_ONE_SEVENTH: return 1.0 / 7.0;
            default: return 1.0 / 2.0;
        }
    }

    private double[] dayPortion(double[] times) {
        double[] t = new double[7];
        for (int i = 0; i < 7; i++) {
            t[i] = times[i] / 24.0;
        }
        return t;
    }

    private double[] tuneTimes(double[] times) {
        for (int i = 0; i < 7; i++) {
            times[i] += offsets[i] / 60.0;
        }
        return times;
    }

    // ---------- Formatting ----------

    public static String formatTime(double time, int format) {
        if (Double.isNaN(time)) return "--:--";
        time = fixHour(time);
        int hours = (int) Math.floor(time);
        int minutes = (int) Math.floor((time - hours) * 60);
        int seconds = (int) Math.floor(((time - hours) * 60 - minutes) * 60);
        if (format == TIME_12H) {
            String suffix = hours < 12 ? "AM" : "PM";
            hours = hours % 12;
            if (hours == 0) hours = 12;
            return String.format("%d:%02d %s", hours, minutes, suffix);
        } else {
            return String.format("%02d:%02d", hours, minutes);
        }
    }

    public static int[] getHoursMinutes(double time) {
        if (Double.isNaN(time)) return new int[]{0, 0};
        time = fixHour(time);
        int hours = (int) Math.floor(time);
        int minutes = (int) Math.floor((time - hours) * 60);
        return new int[]{hours, minutes};
    }

    // ---------- Math Helpers ----------

    private double fixAngle(double a) {
        return a - Math.floor(a / 360.0) * 360.0;
    }

    private static double fixHour(double a) {
        a = a - Math.floor(a / 24.0) * 24.0;
        return a < 0 ? a + 24 : a;
    }

    private double timeDiff(double time1, double time2) {
        return fixHour(time2 - time1);
    }

    private double dsin(double d) { return Math.sin(Math.toRadians(d)); }
    private double dcos(double d) { return Math.cos(Math.toRadians(d)); }
    private double dtan(double d) { return Math.tan(Math.toRadians(d)); }
    private double dasin(double x) { return Math.toDegrees(Math.asin(x)); }
    private double dacos(double x) { return Math.toDegrees(Math.acos(x)); }
    private double datan(double x) { return Math.toDegrees(Math.atan(x)); }
    private double datan2(double y, double x) { return Math.toDegrees(Math.atan2(y, x)); }

    // ---------- Get Current Times ----------

    public double[] getTodayPrayerTimes() {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"));
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        return getPrayerTimesDouble(year, month, day);
    }

    public String[] getTodayPrayerTimesFormatted(int timeFormat) {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"));
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        return getPrayerTimesFormatted(year, month, day, timeFormat);
    }

    /**
     * Get next prayer time as fractional hours, and its name.
     */
    public String[] getNextPrayer(double[] times) {
        String[] names = {"Fajr", "Sunrise", "Dhuhr", "Asr", "Sunset", "Maghrib", "Isha"};
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"));
        double currentHour = now.get(Calendar.HOUR_OF_DAY) + now.get(Calendar.MINUTE) / 60.0 + now.get(Calendar.SECOND) / 3600.0;
        for (int i = 0; i < times.length; i++) {
            if (times[i] > currentHour) {
                return new String[]{names[i], String.valueOf(times[i])};
            }
        }
        // All prayers passed, return tomorrow's Fajr
        return new String[]{"Fajr (tomorrow)", String.valueOf(times[FAJR] + 24)};
    }
}
