package com.khalid.islamicprayertimes.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.khalid.islamicprayertimes.R;
import com.khalid.islamicprayertimes.models.PrayerTimes;
import com.khalid.islamicprayertimes.utils.NotificationHelper;
import com.khalid.islamicprayertimes.utils.PrayerTimesCalculator;
import com.khalid.islamicprayertimes.utils.PrefsManager;
import com.khalid.islamicprayertimes.widget.PrayerWidget;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST = 100;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 101;

    // UI
    private TextView tvLocationName;
    private TextView tvIftarTime;
    private TextView tvIftarCountdown;
    private TextView tvSuhurTime;
    private TextView tvFajrTime;
    private TextView tvDhuhrTime;
    private TextView tvAsrTime;
    private TextView tvMaghribTime;
    private TextView tvIshaTime;
    private TextView tvDate;
    private TextView tvCountdownLabel;

    private FusedLocationProviderClient fusedLocationClient;
    private PrefsManager prefsManager;
    private PrayerTimes currentPrayerTimes;

    private Handler countdownHandler;
    private Runnable countdownRunnable;
    private boolean countingToIftar = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        prefsManager = new PrefsManager(this);
        applyTheme();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupButtons();

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        countdownHandler = new Handler(Looper.getMainLooper());

        checkPermissionsAndLoad();
        setDateHeader();
    }

    private void applyTheme() {
        if (prefsManager.getDarkMode()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    private void initViews() {
        tvLocationName = findViewById(R.id.tv_location_name);
        tvIftarTime = findViewById(R.id.tv_iftar_time);
        tvIftarCountdown = findViewById(R.id.tv_iftar_countdown);
        tvSuhurTime = findViewById(R.id.tv_suhur_time);
        tvFajrTime = findViewById(R.id.tv_fajr_time);
        tvDhuhrTime = findViewById(R.id.tv_dhuhr_time);
        tvAsrTime = findViewById(R.id.tv_asr_time);
        tvMaghribTime = findViewById(R.id.tv_maghrib_time);
        tvIshaTime = findViewById(R.id.tv_isha_time);
        tvDate = findViewById(R.id.tv_date);
        tvCountdownLabel = findViewById(R.id.tv_countdown_label);
    }

    private void setupButtons() {
        ImageButton btnSettings = findViewById(R.id.btn_settings);
        if (btnSettings != null) {
            btnSettings.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            });
        }

        View btnRefreshLocation = findViewById(R.id.btn_refresh_location);
        if (btnRefreshLocation != null) {
            btnRefreshLocation.setOnClickListener(v -> checkPermissionsAndLoad());
        }
    }

    private void setDateHeader() {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"));
        String[] days = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        String[] months = {"January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"};
        String dateStr = days[cal.get(Calendar.DAY_OF_WEEK) - 1] + ", " +
                cal.get(Calendar.DAY_OF_MONTH) + " " +
                months[cal.get(Calendar.MONTH)] + " " +
                cal.get(Calendar.YEAR);
        if (tvDate != null) tvDate.setText(dateStr);
    }

    private void checkPermissionsAndLoad() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_PERMISSION_REQUEST);
        } else {
            requestNotificationPermission();
            getLocation();
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        NOTIFICATION_PERMISSION_REQUEST);
            }
        }
    }

    @SuppressLint("MissingPermission")
    private void getLocation() {
        // First load from cached location
        double cachedLat = prefsManager.getLastLat();
        double cachedLon = prefsManager.getLastLon();
        String cachedName = prefsManager.getLastLocationName();
        if (cachedLat != 0 && cachedLon != 0) {
            loadPrayerTimes(cachedLat, cachedLon, cachedName);
        }

        // Then try fresh GPS
        LocationRequest locationRequest = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10000)
                .setWaitForAccurateLocation(false)
                .setMinUpdateIntervalMillis(5000)
                .setMaxUpdates(1)
                .build();

        fusedLocationClient.requestLocationUpdates(locationRequest, new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                Location location = locationResult.getLastLocation();
                if (location != null) {
                    double lat = location.getLatitude();
                    double lon = location.getLongitude();
                    prefsManager.setLastLocation(lat, lon);
                    resolveLocationName(lat, lon);
                }
                fusedLocationClient.removeLocationUpdates(this);
            }
        }, Looper.getMainLooper());
    }

    private void resolveLocationName(double lat, double lon) {
        new Thread(() -> {
            String locationName = "Bangladesh";
            try {
                Geocoder geocoder = new Geocoder(this, new Locale("en"));
                List<Address> addresses = geocoder.getFromLocation(lat, lon, 1);
                if (addresses != null && !addresses.isEmpty()) {
                    Address addr = addresses.get(0);
                    StringBuilder sb = new StringBuilder();
                    if (addr.getSubLocality() != null) sb.append(addr.getSubLocality()).append(", ");
                    if (addr.getLocality() != null) sb.append(addr.getLocality()).append(", ");
                    if (addr.getAdminArea() != null) sb.append(addr.getAdminArea());
                    locationName = sb.toString().trim();
                    if (locationName.endsWith(",")) locationName = locationName.substring(0, locationName.length() - 1).trim();
                    if (locationName.isEmpty()) locationName = "Bangladesh";
                }
            } catch (IOException e) {
                locationName = prefsManager.getLastLocationName();
            }
            final String finalName = locationName;
            prefsManager.setLastLocationName(finalName);
            runOnUiThread(() -> loadPrayerTimes(lat, lon, finalName));
        }).start();
    }

    private void loadPrayerTimes(double lat, double lon, String locationName) {
        PrayerTimesCalculator calculator = new PrayerTimesCalculator(lat, lon);
        calculator.setCalcMethod(prefsManager.getCalcMethod());
        calculator.setAsrJuristic(prefsManager.getAsrMethod());

        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"));
        double[] times = calculator.getPrayerTimesDouble(
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH)
        );

        int timeFormat = prefsManager.getTimeFormat();
        String[] formattedTimes = calculator.getTodayPrayerTimesFormatted(timeFormat);

        currentPrayerTimes = new PrayerTimes();
        currentPrayerTimes.setFajrDouble(times[PrayerTimesCalculator.FAJR]);
        currentPrayerTimes.setDhuhrDouble(times[PrayerTimesCalculator.DHUHR]);
        currentPrayerTimes.setAsrDouble(times[PrayerTimesCalculator.ASR]);
        currentPrayerTimes.setMaghribDouble(times[PrayerTimesCalculator.MAGHRIB]);
        currentPrayerTimes.setIshaDouble(times[PrayerTimesCalculator.ISHA]);

        // Check for custom times
        if (prefsManager.isUseCustomTimes()) {
            String cf = prefsManager.getCustomTime(PrefsManager.KEY_CUSTOM_FAJR);
            if (!cf.isEmpty()) formattedTimes[0] = cf;
            String cd = prefsManager.getCustomTime(PrefsManager.KEY_CUSTOM_DHUHR);
            if (!cd.isEmpty()) formattedTimes[2] = cd;
            String ca = prefsManager.getCustomTime(PrefsManager.KEY_CUSTOM_ASR);
            if (!ca.isEmpty()) formattedTimes[3] = ca;
            String cm = prefsManager.getCustomTime(PrefsManager.KEY_CUSTOM_MAGHRIB);
            if (!cm.isEmpty()) formattedTimes[5] = cm;
            String ci = prefsManager.getCustomTime(PrefsManager.KEY_CUSTOM_ISHA);
            if (!ci.isEmpty()) formattedTimes[6] = ci;
        }

        currentPrayerTimes.setFajr(formattedTimes[0]);
        currentPrayerTimes.setDhuhr(formattedTimes[2]);
        currentPrayerTimes.setAsr(formattedTimes[3]);
        currentPrayerTimes.setMaghrib(formattedTimes[5]);
        currentPrayerTimes.setIsha(formattedTimes[6]);
        currentPrayerTimes.setLocationName(locationName);

        updateUI(locationName);
        scheduleNotifications(times);
        PrayerWidget.updateAllWidgets(this);
    }

    private void updateUI(String locationName) {
        if (tvLocationName != null) tvLocationName.setText(locationName);
        if (tvSuhurTime != null) tvSuhurTime.setText(currentPrayerTimes.getSuhur());
        if (tvIftarTime != null) tvIftarTime.setText(currentPrayerTimes.getIftar());
        if (tvFajrTime != null) tvFajrTime.setText(currentPrayerTimes.getFajr());
        if (tvDhuhrTime != null) tvDhuhrTime.setText(currentPrayerTimes.getDhuhr());
        if (tvAsrTime != null) tvAsrTime.setText(currentPrayerTimes.getAsr());
        if (tvMaghribTime != null) tvMaghribTime.setText(currentPrayerTimes.getMaghrib());
        if (tvIshaTime != null) tvIshaTime.setText(currentPrayerTimes.getIsha());

        startCountdown();
    }

    private void startCountdown() {
        if (countdownRunnable != null) countdownHandler.removeCallbacks(countdownRunnable);
        if (currentPrayerTimes == null) return;

        countdownRunnable = new Runnable() {
            @Override
            public void run() {
                Calendar now = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"));
                double currentHours = now.get(Calendar.HOUR_OF_DAY) +
                        now.get(Calendar.MINUTE) / 60.0 +
                        now.get(Calendar.SECOND) / 3600.0;

                double iftarTime = currentPrayerTimes.getMaghribDouble();
                double suhurTime = currentPrayerTimes.getSuhurDouble();

                double targetTime;
                String label;

                // After Maghrib -> count to Suhur
                if (currentHours >= iftarTime) {
                    targetTime = suhurTime + 24; // Next day Suhur
                    label = "Suhur starts in";
                    countingToIftar = false;
                } else {
                    targetTime = iftarTime;
                    label = "Iftar in";
                    countingToIftar = true;
                }

                double diffHours = targetTime - currentHours;
                if (diffHours < 0) diffHours += 24;

                int hours = (int) Math.floor(diffHours);
                int minutes = (int) Math.floor((diffHours - hours) * 60);
                int seconds = (int) Math.floor(((diffHours - hours) * 60 - minutes) * 60);

                String countdown = String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds);
                if (tvIftarCountdown != null) tvIftarCountdown.setText(countdown);
                if (tvCountdownLabel != null) tvCountdownLabel.setText(label);

                countdownHandler.postDelayed(this, 1000);
            }
        };
        countdownHandler.post(countdownRunnable);
    }

    private void scheduleNotifications(double[] times) {
        String[] names = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
        String[] keys = {PrefsManager.KEY_NOTIF_FAJR, PrefsManager.KEY_NOTIF_DHUHR,
                PrefsManager.KEY_NOTIF_ASR, PrefsManager.KEY_NOTIF_MAGHRIB, PrefsManager.KEY_NOTIF_ISHA};
        int[] timeIndices = {PrayerTimesCalculator.FAJR, PrayerTimesCalculator.DHUHR,
                PrayerTimesCalculator.ASR, PrayerTimesCalculator.MAGHRIB, PrayerTimesCalculator.ISHA};

        for (int i = 0; i < names.length; i++) {
            if (prefsManager.getNotifEnabled(keys[i])) {
                NotificationHelper.schedulePrayerAlarm(this, names[i], times[timeIndices[i]], i + 100);
            } else {
                NotificationHelper.cancelPrayerAlarm(this, i + 100);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermission();
                getLocation();
            } else {
                Toast.makeText(this, "Location permission required for accurate prayer times", Toast.LENGTH_LONG).show();
                // Load with default Dhaka coordinates
                loadPrayerTimes(23.8103, 90.4125, "Dhaka, Bangladesh");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload if returning from settings
        if (currentPrayerTimes != null) {
            startCountdown();
        }
        applyTheme();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countdownRunnable != null) countdownHandler.removeCallbacks(countdownRunnable);
    }
}
