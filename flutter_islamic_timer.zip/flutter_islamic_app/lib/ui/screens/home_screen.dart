import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/location_provider.dart';
import '../../core/providers/prayer_time_provider.dart';
import '../../core/providers/settings_provider.dart';
import '../../core/providers/notification_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';
import 'dashboard_screen.dart';
import 'prayer_times_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    const DashboardScreen(),
    const PrayerTimesScreen(),
    const SettingsScreen(),
  ];

  final List<String> _screenTitles = [
    'Iftar Countdown',
    'Prayer Times',
    'Settings',
  ];

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  void _initializeApp() async {
    // Initialize location
    final locationProvider =
        context.read<LocationProvider>();
    await locationProvider.refreshLocation();

    // Initialize prayer times
    final prayerTimeProvider =
        context.read<PrayerTimeProvider>();
    await prayerTimeProvider.calculatePrayerTimes();

    // Initialize notifications
    final notificationProvider =
        context.read<NotificationProvider>();
    await notificationProvider.schedulePrayerNotifications(
      prayerTimeProvider.todayPrayers,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          _screenTitles[_selectedIndex],
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
      ),
      body: Stack(
        children: [
          // Background with gradient
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Theme.of(context).scaffoldBackgroundColor,
                  Theme.of(context).brightness == Brightness.dark
                      ? const Color(0xFF1A2332)
                      : const Color(0xFFF5F7FA),
                ],
              ),
            ),
          ),

          // Content
          Consumer<LocationProvider>(
            builder: (context, locationProvider, _) {
              if (locationProvider.isLoading &&
                  !locationProvider.hasLocation) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }

              if (locationProvider.error != null &&
                  !locationProvider.hasLocation) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.location_off,
                        size: 64,
                        color: Theme.of(context).primaryColor,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        locationProvider.error ?? 'Location Error',
                        style: Theme.of(context).textTheme.bodyLarge,
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 32),
                      GlassPillButton(
                        onPressed: () async {
                          await locationProvider
                              .openLocationSettings();
                        },
                        label: 'Enable Location',
                      ),
                    ],
                  ),
                );
              }

              return _screens[_selectedIndex];
            },
          ),
        ],
      ),
      bottomNavigationBar: Theme(
        data: Theme.of(context).copyWith(
          navigationBarTheme: NavigationBarThemeData(
            backgroundColor: Theme.of(context).brightness == Brightness.dark
                ? AppTheme.darkSurface.withOpacity(0.8)
                : AppTheme.lightSurface.withOpacity(0.8),
            elevation: 0,
          ),
        ),
        child: NavigationBar(
          selectedIndex: _selectedIndex,
          onDestinationSelected: (index) {
            setState(() {
              _selectedIndex = index;
            });
          },
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.schedule),
              label: 'Dashboard',
            ),
            NavigationDestination(
              icon: Icon(Icons.mosque),
              label: 'Prayers',
            ),
            NavigationDestination(
              icon: Icon(Icons.settings),
              label: 'Settings',
            ),
          ],
        ),
      ),
    );
  }
}
