import 'package:flutter/material.dart';
import '../services/notification_service.dart';

class NotificationProvider extends ChangeNotifier {
  bool _isEnabled = false;
  bool _isFajrEnabled = true;
  bool _isDhuhrEnabled = true;
  bool _isAsrEnabled = true;
  bool _isMaghribEnabled = true;
  bool _isIshaEnabled = true;

  // Getters
  bool get isEnabled => _isEnabled;
  bool get isFajrEnabled => _isFajrEnabled;
  bool get isDhuhrEnabled => _isDhuhrEnabled;
  bool get isAsrEnabled => _isAsrEnabled;
  bool get isMaghribEnabled => _isMaghribEnabled;
  bool get isIshaEnabled => _isIshaEnabled;

  NotificationProvider() {
    _checkNotificationStatus();
  }

  /// Check if notifications are enabled on device
  Future<void> _checkNotificationStatus() async {
    try {
      _isEnabled = await NotificationService.areNotificationsEnabled();
      notifyListeners();
    } catch (e) {
      print('Error checking notification status: $e');
      _isEnabled = false;
    }
  }

  /// Toggle Fajr notification
  void toggleFajrNotification() {
    _isFajrEnabled = !_isFajrEnabled;
    notifyListeners();
  }

  /// Toggle Dhuhr notification
  void toggleDhuhrNotification() {
    _isDhuhrEnabled = !_isDhuhrEnabled;
    notifyListeners();
  }

  /// Toggle Asr notification
  void toggleAsrNotification() {
    _isAsrEnabled = !_isAsrEnabled;
    notifyListeners();
  }

  /// Toggle Maghrib notification
  void toggleMaghribNotification() {
    _isMaghribEnabled = !_isMaghribEnabled;
    notifyListeners();
  }

  /// Toggle Isha notification
  void toggleIshaNotification() {
    _isIshaEnabled = !_isIshaEnabled;
    notifyListeners();
  }

  /// Get enabled prayers list
  List<String> getEnabledPrayers() {
    final enabled = <String>[];
    if (_isFajrEnabled) enabled.add('Fajr');
    if (_isDhuhrEnabled) enabled.add('Dhuhr');
    if (_isAsrEnabled) enabled.add('Asr');
    if (_isMaghribEnabled) enabled.add('Maghrib');
    if (_isIshaEnabled) enabled.add('Isha');
    return enabled;
  }

  /// Schedule prayer notifications
  Future<void> schedulePrayerNotifications(
    Map<String, DateTime> prayerTimes,
  ) async {
    try {
      await NotificationService.scheduleDailyPrayerNotifications(
        prayerTimes: prayerTimes,
        enabledPrayers: getEnabledPrayers(),
      );
    } catch (e) {
      print('Error scheduling notifications: $e');
    }
  }

  /// Show test notification
  Future<void> showTestNotification(String prayerName) async {
    try {
      await NotificationService.showNotification(
        id: DateTime.now().millisecondsSinceEpoch.toInt(),
        title: 'Test: Time for $prayerName',
        body: 'This is a test notification',
      );
    } catch (e) {
      print('Error showing test notification: $e');
    }
  }

  /// Cancel all notifications
  Future<void> cancelAllNotifications() async {
    try {
      await NotificationService.cancelAllNotifications();
    } catch (e) {
      print('Error canceling notifications: $e');
    }
  }
}
