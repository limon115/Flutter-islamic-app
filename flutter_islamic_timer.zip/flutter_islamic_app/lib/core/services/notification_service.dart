import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;

class NotificationService {
  static final FlutterLocalNotificationsPlugin
      _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  static bool _isInitialized = false;

  /// Initialize notification service
  static Future<void> initialize() async {
    if (_isInitialized) return;

    const AndroidInitializationSettings androidInitializationSettings =
        AndroidInitializationSettings('app_icon');

    const DarwinInitializationSettings darwinInitializationSettings =
        DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const InitializationSettings initializationSettings =
        InitializationSettings(
      android: androidInitializationSettings,
      iOS: darwinInitializationSettings,
    );

    await _flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse details) {
        // Handle notification tap
        print('Notification tapped: ${details.payload}');
      },
    );

    // Create notification channel for Android
    await _createNotificationChannel();

    _isInitialized = true;
  }

  /// Create notification channel (Android 8.0+)
  static Future<void> _createNotificationChannel() async {
    const androidNotificationChannel = AndroidNotificationChannel(
      'prayer_times_channel',
      'Prayer Times',
      description: 'Notifications for Islamic prayer times',
      importance: Importance.max,
      enableVibration: true,
      playSound: true,
    );

    await _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(androidNotificationChannel);
  }

  /// Schedule prayer time notification
  static Future<void> schedulePrayerNotification({
    required int id,
    required String prayerName,
    required DateTime scheduledTime,
  }) async {
    if (!_isInitialized) {
      await initialize();
    }

    try {
      await _flutterLocalNotificationsPlugin.zonedSchedule(
        id,
        'Time for $prayerName',
        'It\'s time to pray $prayerName',
        tz.TZDateTime.from(
          scheduledTime,
          tz.getLocation('Asia/Dhaka'),
        ),
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'prayer_times_channel',
            'Prayer Times',
            importance: Importance.max,
            priority: Priority.high,
            enableVibration: true,
            playSound: true,
            sound: RawResourceAndroidNotificationSound('notification'),
            colorized: true,
            color: 0xFF27AE60,
          ),
          iOS: DarwinNotificationDetails(
            sound: 'notification.aiff',
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAndAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
      );

      print('Prayer notification scheduled for $prayerName at $scheduledTime');
    } catch (e) {
      print('Error scheduling prayer notification: $e');
    }
  }

  /// Schedule Suhur notification (5 minutes before Fajr)
  static Future<void> scheduleSuhurNotification({
    required DateTime fajrTime,
  }) async {
    final suhurTime = fajrTime.subtract(const Duration(minutes: 5));

    await schedulePrayerNotification(
      id: 1,
      prayerName: 'Suhur',
      scheduledTime: suhurTime,
    );
  }

  /// Schedule Iftar notification
  static Future<void> scheduleIftarNotification({
    required DateTime maghribTime,
  }) async {
    await schedulePrayerNotification(
      id: 2,
      prayerName: 'Iftar',
      scheduledTime: maghribTime,
    );
  }

  /// Schedule all prayer notifications for a day
  static Future<void> scheduleDailyPrayerNotifications({
    required Map<String, DateTime> prayerTimes,
    required List<String> enabledPrayers,
  }) async {
    const prayerIds = {
      'Fajr': 10,
      'Dhuhr': 11,
      'Asr': 12,
      'Maghrib': 13,
      'Isha': 14,
    };

    // Cancel existing notifications
    await cancelAllNotifications();

    // Schedule new notifications
    for (final prayer in enabledPrayers) {
      if (prayerTimes.containsKey(prayer)) {
        await schedulePrayerNotification(
          id: prayerIds[prayer] ?? 99,
          prayerName: prayer,
          scheduledTime: prayerTimes[prayer]!,
        );
      }
    }
  }

  /// Cancel notification by ID
  static Future<void> cancelNotification(int id) async {
    await _flutterLocalNotificationsPlugin.cancel(id);
  }

  /// Cancel all notifications
  static Future<void> cancelAllNotifications() async {
    await _flutterLocalNotificationsPlugin.cancelAll();
  }

  /// Show instant notification
  static Future<void> showNotification({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    if (!_isInitialized) {
      await initialize();
    }

    await _flutterLocalNotificationsPlugin.show(
      id,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'prayer_times_channel',
          'Prayer Times',
          importance: Importance.max,
          priority: Priority.high,
          enableVibration: true,
          playSound: true,
        ),
        iOS: DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
      payload: payload,
    );
  }

  /// Check if notifications are enabled
  static Future<bool> areNotificationsEnabled() async {
    final isEnabled = await _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.areNotificationsEnabled();

    return isEnabled ?? false;
  }
}
