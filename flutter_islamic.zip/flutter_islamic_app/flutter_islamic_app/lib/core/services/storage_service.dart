import 'package:hive_flutter/hive_flutter.dart';
import '../models/user_profile_model.dart';
import '../models/prayer_time_model.dart';

class StorageService {
  static const String _profileBoxName = 'userProfileBox';
  static const String _prayerTimeBoxName = 'prayerTimeBox';
  static const String _scheduleBoxName = 'scheduleBox';
  static const String _settingsBoxName = 'settingsBox';

  static const String _profileKey = 'userProfile';
  static const String _darkModeKey = 'darkMode';
  static const String _timeFormatKey = 'timeFormat'; // 12 or 24
  static const String _enabledPrayersKey = 'enabledPrayers';

  // Profile Management
  static Future<void> saveProfile(UserProfile profile) async {
    try {
      final box = await Hive.openBox<UserProfile>(_profileBoxName);
      await box.put(_profileKey, profile);
    } catch (e) {
      print('Error saving profile: $e');
    }
  }

  static Future<UserProfile?> getProfile() async {
    try {
      final box = await Hive.openBox<UserProfile>(_profileBoxName);
      return box.get(_profileKey);
    } catch (e) {
      print('Error getting profile: $e');
      return null;
    }
  }

  static Future<bool> profileExists() async {
    try {
      final box = await Hive.openBox<UserProfile>(_profileBoxName);
      return box.containsKey(_profileKey);
    } catch (e) {
      print('Error checking profile: $e');
      return false;
    }
  }

  // Settings Management
  static Future<void> setDarkMode(bool isDark) async {
    try {
      final box = await Hive.openBox(_settingsBoxName);
      await box.put(_darkModeKey, isDark);
    } catch (e) {
      print('Error setting dark mode: $e');
    }
  }

  static Future<bool> isDarkMode() async {
    try {
      final box = await Hive.openBox(_settingsBoxName);
      return box.get(_darkModeKey, defaultValue: false) as bool;
    } catch (e) {
      print('Error getting dark mode: $e');
      return false;
    }
  }

  static Future<void> setTimeFormat(int format) async {
    // 12 or 24
    try {
      final box = await Hive.openBox(_settingsBoxName);
      await box.put(_timeFormatKey, format);
    } catch (e) {
      print('Error setting time format: $e');
    }
  }

  static Future<int> getTimeFormat() async {
    try {
      final box = await Hive.openBox(_settingsBoxName);
      return box.get(_timeFormatKey, defaultValue: 12) as int;
    } catch (e) {
      print('Error getting time format: $e');
      return 12;
    }
  }

  static Future<void> setEnabledPrayers(List<String> prayers) async {
    try {
      final box = await Hive.openBox(_settingsBoxName);
      await box.put(_enabledPrayersKey, prayers);
    } catch (e) {
      print('Error setting enabled prayers: $e');
    }
  }

  static Future<List<String>> getEnabledPrayers() async {
    try {
      final box = await Hive.openBox(_settingsBoxName);
      final prayers = box.get(_enabledPrayersKey) as List?;
      return prayers?.cast<String>().toList() ??
          ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
    } catch (e) {
      print('Error getting enabled prayers: $e');
      return ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
    }
  }

  // Prayer Time Management
  static Future<void> savePrayerTime(PrayerTime prayerTime) async {
    try {
      final box = await Hive.openBox<PrayerTime>(_prayerTimeBoxName);
      final key =
          '${prayerTime.name}_${prayerTime.date.year}_${prayerTime.date.month}_${prayerTime.date.day}';
      await box.put(key, prayerTime);
    } catch (e) {
      print('Error saving prayer time: $e');
    }
  }

  static Future<PrayerTime?> getPrayerTime(
    String prayerName,
    DateTime date,
  ) async {
    try {
      final box = await Hive.openBox<PrayerTime>(_prayerTimeBoxName);
      final key =
          '${prayerName}_${date.year}_${date.month}_${date.day}';
      return box.get(key);
    } catch (e) {
      print('Error getting prayer time: $e');
      return null;
    }
  }

  static Future<void> saveDailySchedule(DailyPrayerSchedule schedule) async {
    try {
      final box =
          await Hive.openBox<DailyPrayerSchedule>(_scheduleBoxName);
      final key =
          '${schedule.date.year}_${schedule.date.month}_${schedule.date.day}';
      await box.put(key, schedule);
    } catch (e) {
      print('Error saving daily schedule: $e');
    }
  }

  static Future<DailyPrayerSchedule?> getDailySchedule(DateTime date) async {
    try {
      final box =
          await Hive.openBox<DailyPrayerSchedule>(_scheduleBoxName);
      final key =
          '${date.year}_${date.month}_${date.day}';
      return box.get(key);
    } catch (e) {
      print('Error getting daily schedule: $e');
      return null;
    }
  }

  static Future<void> deleteOldSchedules(
    DateTime beforeDate,
  ) async {
    try {
      final box =
          await Hive.openBox<DailyPrayerSchedule>(_scheduleBoxName);
      final keysToDelete = <String>[];

      for (final key in box.keys) {
        final schedule = box.get(key);
        if (schedule != null && schedule.date.isBefore(beforeDate)) {
          keysToDelete.add(key as String);
        }
      }

      for (final key in keysToDelete) {
        await box.delete(key);
      }
    } catch (e) {
      print('Error deleting old schedules: $e');
    }
  }

  // Clear all data
  static Future<void> clearAllData() async {
    try {
      await Hive.deleteBoxFromDisk(_profileBoxName);
      await Hive.deleteBoxFromDisk(_prayerTimeBoxName);
      await Hive.deleteBoxFromDisk(_scheduleBoxName);
      await Hive.deleteBoxFromDisk(_settingsBoxName);
    } catch (e) {
      print('Error clearing all data: $e');
    }
  }
}
