import 'package:flutter/material.dart';
import '../services/location_service.dart';

class LocationProvider extends ChangeNotifier {
  double _latitude = 0.0;
  double _longitude = 0.0;
  String _locationName = 'Fetching location...';
  bool _isLoading = true;
  String? _error;

  // Getters
  double get latitude => _latitude;
  double get longitude => _longitude;
  String get locationName => _locationName;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get hasLocation => _latitude != 0.0 && _longitude != 0.0;

  LocationProvider() {
    _initializeLocation();
  }

  /// Initialize location on app start
  Future<void> _initializeLocation() async {
    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      // Check if location services are enabled
      final isEnabled = await LocationService.isLocationServiceEnabled();
      if (!isEnabled) {
        _error = 'Location services are disabled';
        _isLoading = false;
        notifyListeners();
        return;
      }

      // Try to get current location
      final position = await LocationService.getCurrentLocation();

      if (position != null) {
        _latitude = position.latitude;
        _longitude = position.longitude;

        // Get location name (reverse geocoding)
        _locationName = await LocationService.getLocationName(
          _latitude,
          _longitude,
        );

        _error = null;
      } else {
        _error = 'Unable to get location';
      }
    } catch (e) {
      _error = 'Error: ${e.toString()}';
      print('Location initialization error: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Update location manually
  Future<void> updateLocation(
    double? latitude,
    double? longitude,
    String? locationName,
  ) async {
    if (latitude != null && longitude != null) {
      if (_latitude != latitude || _longitude != longitude) {
        _latitude = latitude;
        _longitude = longitude;

        if (locationName != null && locationName.isNotEmpty) {
          _locationName = locationName;
        } else {
          _locationName = 'Fetching location name...';
          // Fetch location name asynchronously
          try {
            _locationName = await LocationService.getLocationName(
              latitude,
              longitude,
            );
          } catch (e) {
            _locationName =
                'Bangladesh (${latitude.toStringAsFixed(4)}, ${longitude.toStringAsFixed(4)})';
          }
        }

        _error = null;
        notifyListeners();
      }
    }
  }

  /// Refresh current location
  Future<void> refreshLocation() async {
    await _initializeLocation();
  }

  /// Open location settings
  Future<void> openLocationSettings() async {
    await LocationService.openLocationSettings();
  }

  /// Reset error
  void clearError() {
    _error = null;
    notifyListeners();
  }
}
