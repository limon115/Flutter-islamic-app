import 'package:flutter/material.dart';
import '../services/storage_service.dart';
import '../models/user_profile_model.dart';

class SettingsProvider extends ChangeNotifier {
  bool _isDarkMode = false;
  int _timeFormat = 12; // 12 or 24
  UserProfile? _userProfile;
  List<String> _enabledPrayers = [
    'Fajr',
    'Dhuhr',
    'Asr',
    'Maghrib',
    'Isha'
  ];

  // Getters
  bool get isDarkMode => _isDarkMode;
  int get timeFormat => _timeFormat;
  UserProfile? get userProfile => _userProfile;
  List<String> get enabledPrayers => _enabledPrayers;

  SettingsProvider() {
    _loadSettings();
  }

  /// Load all settings from storage
  Future<void> _loadSettings() async {
    try {
      _isDarkMode = await StorageService.isDarkMode();
      _timeFormat = await StorageService.getTimeFormat();
      _userProfile = await StorageService.getProfile();
      _enabledPrayers = await StorageService.getEnabledPrayers();
      notifyListeners();
    } catch (e) {
      print('Error loading settings: $e');
    }
  }

  /// Toggle dark mode
  Future<void> toggleDarkMode() async {
    _isDarkMode = !_isDarkMode;
    await StorageService.setDarkMode(_isDarkMode);
    notifyListeners();
  }

  /// Set dark mode explicitly
  Future<void> setDarkMode(bool isDark) async {
    if (_isDarkMode != isDark) {
      _isDarkMode = isDark;
      await StorageService.setDarkMode(_isDarkMode);
      notifyListeners();
    }
  }

  /// Set time format (12 or 24)
  Future<void> setTimeFormat(int format) async {
    if (format == 12 || format == 24) {
      _timeFormat = format;
      await StorageService.setTimeFormat(_timeFormat);
      notifyListeners();
    }
  }

  /// Save user profile
  Future<void> setUserProfile(UserProfile profile) async {
    _userProfile = profile;
    await StorageService.saveProfile(profile);
    notifyListeners();
  }

  /// Update user profile name
  Future<void> updateProfileName(String name) async {
    if (_userProfile != null) {
      _userProfile = _userProfile!.copyWith(name: name);
      await StorageService.saveProfile(_userProfile!);
      notifyListeners();
    }
  }

  /// Update profile image path
  Future<void> updateProfileImage(String imagePath) async {
    if (_userProfile != null) {
      _userProfile = _userProfile!.copyWith(profileImagePath: imagePath);
      await StorageService.saveProfile(_userProfile!);
      notifyListeners();
    }
  }

  /// Toggle prayer notification
  Future<void> togglePrayerNotification(String prayerName) async {
    if (_enabledPrayers.contains(prayerName)) {
      _enabledPrayers.remove(prayerName);
    } else {
      _enabledPrayers.add(prayerName);
    }
    await StorageService.setEnabledPrayers(_enabledPrayers);
    notifyListeners();
  }

  /// Set enabled prayers
  Future<void> setEnabledPrayers(List<String> prayers) async {
    _enabledPrayers = prayers;
    await StorageService.setEnabledPrayers(_enabledPrayers);
    notifyListeners();
  }

  /// Check if profile is set
  bool get isProfileSet => _userProfile != null;
}

extension UserProfileExtension on UserProfile {
  UserProfile copyWith({
    String? name,
    String? profileImagePath,
    DateTime? createdAt,
  }) {
    return UserProfile(
      name: name ?? this.name,
      profileImagePath: profileImagePath ?? this.profileImagePath,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
