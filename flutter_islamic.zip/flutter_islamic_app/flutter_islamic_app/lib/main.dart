import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';
import 'package:timezone/data/latest.dart' as tz;

import 'core/models/prayer_time_model.dart';
import 'core/models/user_profile_model.dart';
import 'core/providers/location_provider.dart';
import 'core/providers/prayer_time_provider.dart';
import 'core/providers/settings_provider.dart';
import 'core/providers/notification_provider.dart';
import 'core/services/notification_service.dart';
import 'ui/theme/app_theme.dart';
import 'ui/screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Hive
  await Hive.initFlutter();
  
  // Register Hive Adapters
  Hive.registerAdapter(UserProfileAdapter());
  Hive.registerAdapter(PrayerTimeAdapter());
  
  // Initialize timezone data
  tz.initializeTimeZones();

  // Initialize local notifications
  await NotificationService.initialize();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => SettingsProvider(),
        ),
        ChangeNotifierProvider(
          create: (_) => LocationProvider(),
        ),
        ChangeNotifierProxyProvider<LocationProvider, PrayerTimeProvider>(
          create: (_) => PrayerTimeProvider(),
          update: (_, locationProvider, prayerTimeProvider) {
            prayerTimeProvider?.updateLocation(
              locationProvider.latitude,
              locationProvider.longitude,
              locationProvider.locationName,
            );
            return prayerTimeProvider ?? PrayerTimeProvider();
          },
        ),
        ChangeNotifierProvider(
          create: (_) => NotificationProvider(),
        ),
      ],
      child: Consumer<SettingsProvider>(
        builder: (context, settingsProvider, _) {
          return MaterialApp(
            title: 'Islamic Prayer Times',
            theme: AppTheme.lightTheme,
            darkTheme: AppTheme.darkTheme,
            themeMode: settingsProvider.isDarkMode
                ? ThemeMode.dark
                : ThemeMode.light,
            home: const HomeScreen(),
            debugShowCheckedModeBanner: false,
          );
        },
      ),
    );
  }
}
