import 'package:flutter/material.dart';

class CountdownTimer extends StatefulWidget {
  final DateTime targetTime;
  final ValueChanged<Duration>? onTick;
  final VoidCallback? onComplete;

  const CountdownTimer({
    Key? key,
    required this.targetTime,
    this.onTick,
    this.onComplete,
  }) : super(key: key);

  @override
  State<CountdownTimer> createState() => _CountdownTimerState();
}

class _CountdownTimerState extends State<CountdownTimer> {
  late Duration _remainingTime;
  late Stream<Duration> _countdownStream;

  @override
  void initState() {
    super.initState();
    _updateRemainingTime();
    _startCountdown();
  }

  void _updateRemainingTime() {
    final now = DateTime.now();
    if (now.isBefore(widget.targetTime)) {
      _remainingTime = widget.targetTime.difference(now);
    } else {
      _remainingTime = Duration.zero;
    }
  }

  void _startCountdown() {
    _countdownStream = Stream.periodic(
      const Duration(seconds: 1),
      (count) {
        _updateRemainingTime();
        widget.onTick?.call(_remainingTime);

        if (_remainingTime <= Duration.zero) {
          widget.onComplete?.call();
        }

        return _remainingTime;
      },
    );
  }

  @override
  void didUpdateWidget(CountdownTimer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.targetTime != widget.targetTime) {
      _updateRemainingTime();
    }
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return '${twoDigits(duration.inHours)}:$twoDigitMinutes:$twoDigitSeconds';
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Duration>(
      stream: _countdownStream,
      initialData: _remainingTime,
      builder: (context, snapshot) {
        final remaining = snapshot.data ?? _remainingTime;
        return Text(
          _formatDuration(remaining),
          style: Theme.of(context).textTheme.displayLarge?.copyWith(
                fontWeight: FontWeight.bold,
                fontFamily: 'Poppins',
              ),
        );
      },
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}

/// Animated countdown card
class CountdownCard extends StatelessWidget {
  final DateTime targetTime;
  final String label;
  final TextStyle? textStyle;

  const CountdownCard({
    Key? key,
    required this.targetTime,
    required this.label,
    this.textStyle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.bodyLarge,
        ),
        const SizedBox(height: 8),
        CountdownTimer(targetTime: targetTime),
      ],
    );
  }
}
