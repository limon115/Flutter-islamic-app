import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/providers/location_provider.dart';
import '../../core/providers/prayer_time_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';
import '../widgets/countdown_timer.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late DateTime _currentDate;

  @override
  void initState() {
    super.initState();
    _currentDate = DateTime.now();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.only(top: 100, left: 16, right: 16, bottom: 32),
      child: Consumer2<LocationProvider, PrayerTimeProvider>(
        builder: (context, locationProvider, prayerTimeProvider, _) {
          final isDark =
              Theme.of(context).brightness == Brightness.dark;

          return Column(
            children: [
              // Location Card
              GlassCard(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Your Location',
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            locationProvider.locationName,
                            style: Theme.of(context)
                                .textTheme
                                .titleLarge,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    Icon(
                      Icons.location_on,
                      color: Theme.of(context).primaryColor,
                      size: 28,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // Today's Date
              Text(
                DateFormat('EEEE, MMMM d, y')
                    .format(_currentDate),
                style: Theme.of(context).textTheme.bodyLarge,
              ),

              const SizedBox(height: 32),

              if (prayerTimeProvider.isLoading)
                const Center(child: CircularProgressIndicator())
              else if (prayerTimeProvider.error != null)
                GlassCard(
                  child: Center(
                    child: Column(
                      children: [
                        Icon(
                          Icons.error_outline,
                          size: 48,
                          color: Colors.red,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          prayerTimeProvider.error ?? 'Unknown error',
                          style: Theme.of(context).textTheme.bodyLarge,
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                )
              else
                Column(
                  children: [
                    // Iftar Countdown Main Card
                    GlassCard(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        children: [
                          Text(
                            'Time to Iftar',
                            style: Theme.of(context)
                                .textTheme
                                .bodyLarge
                                ?.copyWith(
                                  color: AppTheme.textGray,
                                ),
                          ),
                          const SizedBox(height: 16),
                          CountdownTimer(
                            targetTime: prayerTimeProvider.iftarTime,
                          ),
                          const SizedBox(height: 16),
                          Divider(
                            color: Colors.white.withOpacity(0.2),
                          ),
                          const SizedBox(height: 16),
                          Row(
                            mainAxisAlignment:
                                MainAxisAlignment.spaceAround,
                            children: [
                              Column(
                                children: [
                                  Text(
                                    'Iftar',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodySmall,
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    DateFormat('h:mm a')
                                        .format(
                                      prayerTimeProvider.iftarTime,
                                    ),
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleLarge,
                                  ),
                                ],
                              ),
                              Container(
                                width: 1,
                                height: 60,
                                color: Colors.white.withOpacity(0.2),
                              ),
                              Column(
                                children: [
                                  Text(
                                    'Suhur',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodySmall,
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    DateFormat('h:mm a')
                                        .format(
                                      prayerTimeProvider.suhurTime,
                                    ),
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleLarge,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 32),

                    // Today's Prayer Schedule
                    Text(
                      'Today\'s Prayer Schedule',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 16),

                    // Prayer Times Grid
                    ...prayerTimeProvider.todayPrayers.entries
                        .map(
                          (entry) => Padding(
                            padding:
                                const EdgeInsets.only(bottom: 12),
                            child: GlassCard(
                              padding:
                                  const EdgeInsets.symmetric(
                                vertical: 12,
                                horizontal: 16,
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment
                                        .spaceBetween,
                                children: [
                                  Text(
                                    entry.key,
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleLarge,
                                  ),
                                  Text(
                                    DateFormat('h:mm a')
                                        .format(entry.value),
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleLarge
                                        ?.copyWith(
                                          color: Theme.of(
                                                  context)
                                              .primaryColor,
                                        ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                        .toList(),
                  ],
                ),
            ],
          );
        },
      ),
    );
  }
}
