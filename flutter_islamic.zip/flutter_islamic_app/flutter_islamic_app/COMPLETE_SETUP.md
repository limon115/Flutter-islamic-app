# 🕌 Islamic Prayer Times - Complete Setup & Build Guide

## 📚 Documentation Index

This guide covers everything you need to:
1. ✅ Understand the project structure
2. ✅ Build the APK (with or without PC)
3. ✅ Install on your Android device
4. ✅ Use and customize the app
5. ✅ Troubleshoot issues

---

## 🎯 Quick Reference

| Task | Guide |
|------|-------|
| **Build without PC** | See: "Option 1: GitHub Actions (No PC)" |
| **Build with PC** | See: "Option 2: Local PC Build" |
| **Install APK** | See: "Installing on Android Phone" |
| **Use the app** | See: "Using the App" |
| **Fix issues** | See: "Troubleshooting" |

---

## 🏗️ Project Architecture

### Technology Stack

```
┌─────────────────────────────────────┐
│      Flutter UI Layer                │
│  (Glassmorphism Screens)            │
└─────────────┬───────────────────────┘
              │
┌─────────────v───────────────────────┐
│    Provider State Management         │
│  (Location, Prayer Times, Settings) │
└─────────────┬───────────────────────┘
              │
┌─────────────v───────────────────────┐
│      Service Layer                   │
│ • Location (GPS + Geocoding)        │
│ • Prayer Times (Adhan calc)         │
│ • Notifications (Local)             │
│ • Storage (Hive DB)                 │
└─────────────┬───────────────────────┘
              │
┌─────────────v───────────────────────┐
│   Android Native Layer               │
│  • Home Screen Widget                │
│  • Location Services                 │
│  • Notification System              │
└─────────────────────────────────────┘
```

### Key Packages

| Package | Purpose | Version |
|---------|---------|---------|
| `adhan` | Prayer time calculations | 2.0.0 |
| `geolocator` | GPS location services | 11.0.0 |
| `geocoding` | Reverse geocoding | 2.1.1 |
| `hive` | Local database | 2.2.3 |
| `provider` | State management | 6.1.0 |
| `flutter_local_notifications` | Push notifications | 16.3.0 |
| `glassmorphism` | UI effects | 3.0.0 |

---

## 🚀 OPTION 1: Build Without PC (GitHub Actions)

### Prerequisites
- ✅ GitHub account (free)
- ✅ Internet browser
- ✅ Android phone

### Complete Steps

#### Step 1: Fork the Repository
```
1. Open GitHub website
2. Go to the repository
3. Click "Fork" button (top right)
4. Click "Create fork"
```

#### Step 2: Enable GitHub Actions
```
1. Go to your forked repository
2. Click "Settings"
3. Click "Actions > General"
4. Select "Allow all actions"
5. Click "Save"
```

#### Step 3: Trigger Build
```
1. Click "Actions" tab
2. Click "Build APK Release" workflow
3. Click "Run workflow" button
4. Select branch (choose "main")
5. Click "Run workflow" (green button)
```

**Wait Time:** 7-10 minutes

#### Step 4: Download APK
```
1. Go to "Actions" tab
2. Click on the successful workflow (green ✓)
3. Scroll to "Artifacts"
4. Click "release-apk"
5. Your browser downloads: app-release.apk
```

**File Size:** ~55 MB

#### Step 5: Transfer to Phone
Choose one method:

**Method A: Email**
```
1. Email yourself the APK
2. Open Gmail on phone
3. Download attachment
```

**Method B: Cloud Storage**
```
1. Upload to Google Drive
2. Open on phone
3. Download file
```

**Method C: USB Cable** (Recommended)
```
1. Connect phone via USB
2. Enable file transfer
3. Copy APK to Downloads folder
```

### ✅ Build Complete!

Move to "Installing on Android Phone" section below.

---

## 💻 OPTION 2: Build With PC

### Prerequisites
```
✅ Windows, Mac, or Linux PC
✅ Flutter SDK 3.16.0+
✅ Java JDK 11+
✅ Android SDK
✅ Git
```

### Installation Steps

#### Step 1: Install Flutter
```bash
# Download from https://flutter.dev/docs/get-started/install

# Verify installation
flutter --version
flutter doctor
```

#### Step 2: Clone Repository
```bash
git clone <repository-url>
cd flutter_islamic_app
```

#### Step 3: Get Dependencies
```bash
flutter pub get

# Generate code (Hive adapters)
flutter pub run build_runner build --delete-conflicting-outputs
```

#### Step 4: Build APK

**Debug APK** (for testing):
```bash
flutter build apk --debug
```

**Release APK** (for production):
```bash
flutter build apk --release
```

**Split APKs** (smaller size):
```bash
flutter build apk --split-per-abi --release
```

#### Step 5: Find APK
- Release: `build/app/outputs/flutter-apk/app-release.apk`
- Debug: `build/app/outputs/flutter-apk/app-debug.apk`
- Split: `build/app/outputs/flutter-apk/app-*.apk`

#### Step 6: Install on Device

**Option A: USB**
```bash
flutter install
```

**Option B: Manual**
```bash
adb install build/app/outputs/flutter-apk/app-release.apk
```

**Option C: Transfer File**
```
Copy APK to phone via USB cable
```

### ✅ Build Complete!

Move to "Installing on Android Phone" section below.

---

## 📱 Installing on Android Phone

### Prerequisites
- ✅ APK file downloaded
- ✅ Android 5.0+ (API 21)
- ✅ ~50MB free storage

### Installation Process

#### Step 1: Transfer File
1. Connect phone to PC (if using USB method)
2. Copy `app-release.apk` to **Downloads** folder
3. Or download directly on phone via browser/email

#### Step 2: Enable Unknown Sources
```
Settings > Apps > Special app access > Install unknown apps
→ Select your downloader (Chrome, Gmail, Files, etc.)
→ Toggle "Allow from this source"
```

#### Step 3: Install APK
```
1. Open "Files" or "File Manager"
2. Navigate to "Downloads"
3. Find "app-release.apk"
4. Tap it once to select
5. Tap "Install"
6. Wait for installation (30 seconds - 1 minute)
7. Tap "Open" when done
```

#### Step 4: Grant Permissions
First launch will ask for:

**Location Permission:**
- Choose: "Allow all the time"
- (Required for accurate prayer times)
- Only used locally on your device

**Notification Permission:**
- Choose: "Allow"
- (For prayer time reminders)

#### Step 5: Create Profile
- Enter your name
- Tap "Save Profile"

### ✅ Installation Complete!

The app is now ready to use! 🎉

---

## 🎯 Using the App

### Main Features

#### 1. Dashboard (Default Home)
```
Displays:
- Your current location
- Iftar countdown (live updating)
- Today's Suhur time
- Today's complete prayer schedule

Actions:
- Pull to refresh location
- Tap location card to update
```

#### 2. Prayer Times Screen
```
View all 5 daily prayers:
- Fajr (dawn)
- Dhuhr (noon)
- Asr (afternoon)
- Maghrib (sunset)
- Isha (night)

Actions:
- Tap any prayer to customize time
- Toggle between today/tomorrow
- Auto-calculated from your GPS location
```

#### 3. Settings Screen

**Profile Tab:**
- Add/edit your name
- Change profile photo (coming soon)

**Appearance Tab:**
- Toggle Dark Mode
- Choose time format (12/24 hour)

**Notifications Tab:**
- Enable/disable alerts per prayer
- Receive at exact prayer time
- Works even with low battery

**About Tab:**
- App information
- Developer details
- Feature list

### Optional: Add Home Widget

```
1. Long-press home screen
2. Tap "Widgets" or "Add widget"
3. Search "Islamic Prayer Times"
4. Drag to home screen
5. Adjust size (auto-resizes)

Widget shows:
- Current Iftar countdown
- Updates every minute
```

---

## 🔧 Configuration & Customization

### Change Prayer Calculation Method

Edit: `lib/core/services/prayer_time_service.dart`

```dart
static const CalculationMethod calculationMethod =
    CalculationMethod.MuslimWorldLeague; // Change method here
```

Available methods:
- Muslim World League (default)
- ISNA
- Makkah
- AlAzhar
- Karachi (UISK)
- Diyanet
- Singapore
- Jafari

### Change Color Scheme

Edit: `lib/ui/theme/app_theme.dart`

```dart
static const Color primaryGreen = Color(0xFF27AE60); // Change hex color
```

Color palette to customize:
- Primary green: `#27AE60`
- Light green: `#2ECC71`
- Dark green: `#1E8449`

### Change App Name

1. Edit: `pubspec.yaml`
   ```yaml
   name: islamic_prayer_times  # Change here
   ```

2. Edit: `lib/main.dart`
   ```dart
   title: 'Islamic Prayer Times',  # Change here
   ```

3. Rebuild and redeploy

---

## 🛠️ Troubleshooting

### Installation Issues

**"Parse error" or "Corrupted file"**
- Delete APK file
- Download again from GitHub
- Try a different download method
- Use USB cable method instead

**"Unknown sources disabled"**
- Go to: Settings > Apps
- Search for your browser/download app
- Tap it
- Permissions > Install unknown apps
- Toggle ON

**"App not installed"**
- Not enough storage (need 50+ MB)
- Android version too old (need 5.0+)
- Try uninstalling older version first

### Runtime Issues

**Prayer times show "Loading..."**
```
✓ Check: Internet is on (first time only)
✓ Check: Location permission granted
✓ Check: GPS is enabled
✓ Wait: 30 seconds for calculation
✓ Restart: Close and reopen app
```

**Location not updating**
```
✓ Settings > Apps > Permissions > Location
✓ Change to: "Allow all the time"
✓ Or toggle off/on to refresh
✓ Check: Device GPS is on
```

**Notifications not working**
```
✓ Settings > Apps > Islamic Prayer Times > Notifications
✓ Toggle: All notifications ON
✓ Check: Do Not Disturb is OFF
✓ Allow: App in notification settings
```

**Countdown not updating**
```
✓ Check: Device time is correct
✓ Check: App is not in battery saver mode
✓ Close other apps using location
✓ Restart phone if needed
```

**Dark mode not applying**
```
✓ Go to: Settings (in app)
✓ Appearance tab
✓ Toggle Dark Mode
✓ Restart app if needed
```

---

## 📊 Performance & Battery

### Optimize Battery Usage
```
1. App uses minimal background processes
2. Prayer times calculated once per day
3. Widget updates every minute (not continuous)
4. Location only accessed on app open
5. Notifications are local (no network)
```

### Reduce Data Usage
```
1. All calculations are local
2. No tracking or analytics
3. No ads or extra servers
4. Locations cached for offline use
5. First setup: ~1MB (reverse geocoding)
6. Daily use: <1KB
```

---

## 🔐 Privacy & Security

### Your Data
- ✅ All stored locally on device
- ✅ Never sent to servers
- ✅ Not shared with third parties
- ✅ Can be deleted anytime in Settings

### Permissions Explained
- **Location:** Only used to calculate prayer times
- **Notifications:** Only for prayer time alerts
- **Storage:** To save your profile locally
- **Internet:** Only first time for reverse geocoding

### Offline Capability
- ✅ Works completely offline after setup
- ✅ Prayer times cached locally
- ✅ Notifications work without internet
- ✅ Can use for weeks without connection

---

## 🔄 Updating the App

### Get Latest Version

**If built from GitHub:**
1. Go to Actions tab
2. Run workflow again
3. Download new APK
4. Uninstall old app
5. Install new APK

**Automatic Updates:**
- Enable for Google Play Store version (future)

### Backup Your Data

Data automatically backed up:
- ✓ Profile information
- ✓ Custom prayer times
- ✓ Settings & preferences
- ✓ Notification settings

---

## 🚀 Advanced Features

### Manual Prayer Time Override
```
1. Go to: Prayer Times screen
2. Tap any prayer time
3. Select new time in picker
4. Saved automatically
5. Toggle: Appearance to show custom time
```

### Export Settings (Planned)
```
Upcoming feature:
- Export profile as JSON
- Share settings with others
- Backup to cloud
```

### Multiple Locations (Planned)
```
Upcoming feature:
- Save favorite locations
- Quick switch between cities
- Travel mode
```

---

## 📞 Getting Help

### Check These First
1. Read this guide again
2. Check Troubleshooting section
3. Review build logs (GitHub Actions)
4. Check app permissions in Settings

### Report Issues
- GitHub Issues tab (if you have the repo)
- Email: dev@islamicprayertimes.com
- Include: Android version, error message, what happened

### Common Error Messages

| Error | Solution |
|-------|----------|
| "Location unavailable" | Enable Location in Settings |
| "Prayer times error" | Check internet, restart app |
| "Notification failed" | Enable Notifications in Settings |
| "Parse error on APK" | Download APK again |
| "App crashes on open" | Clear app data, reinstall |

---

## 📚 File Structure Reference

```
islamic_prayer_app/
├── lib/                           # All Flutter code
│   ├── main.dart                  # App entry point
│   ├── core/
│   │   ├── models/                # Data models
│   │   │   ├── user_profile_model.dart
│   │   │   └── prayer_time_model.dart
│   │   ├── providers/             # State management
│   │   │   ├── location_provider.dart
│   │   │   ├── prayer_time_provider.dart
│   │   │   ├── settings_provider.dart
│   │   │   └── notification_provider.dart
│   │   └── services/              # Business logic
│   │       ├── location_service.dart
│   │       ├── prayer_time_service.dart
│   │       ├── notification_service.dart
│   │       └── storage_service.dart
│   └── ui/                        # User interface
│       ├── theme/
│       │   └── app_theme.dart     # Colors, fonts
│       ├── widgets/               # Custom components
│       │   ├── glass_card.dart
│       │   └── countdown_timer.dart
│       └── screens/               # Full page screens
│           ├── home_screen.dart
│           ├── dashboard_screen.dart
│           ├── prayer_times_screen.dart
│           └── settings_screen.dart
├── android/                       # Android native code
│   ├── app/
│   │   ├── build.gradle          # Gradle config
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       ├── kotlin/
│   │       │   └── IftarCountdownWidget.kt
│   │       └── res/
│   │           ├── layout/       # Widget layout
│   │           ├── drawable/     # Widget graphics
│   │           ├── values/       # Colors, strings
│   │           └── xml/          # Widget metadata
├── pubspec.yaml                   # Flutter dependencies
├── README.md                       # Project overview
├── GITHUB_ACTIONS_GUIDE.md        # No-PC build guide
└── .github/
    └── workflows/
        └── build_apk.yml          # CI/CD pipeline
```

---

## 🎓 Learning Resources

### Flutter
- Official: https://flutter.dev
- State Management: https://pub.dev/packages/provider
- Widgets: https://flutter.dev/docs/development/ui/widgets

### Prayer Time Calculations
- Adhan Package: https://pub.dev/packages/adhan
- Islamic Society: https://www.islamicfinder.org

### Android Development
- Android Docs: https://developer.android.com
- Widgets: https://developer.android.com/guide/topics/appwidgets

---

## 🎉 Success Checklist

Before considering your setup complete, verify:

- [ ] APK installed on phone
- [ ] Location permission granted
- [ ] Notification permission granted
- [ ] Profile created with your name
- [ ] Prayer times displaying correctly
- [ ] Iftar countdown updating
- [ ] Dark mode can be toggled
- [ ] Prayer times can be tapped
- [ ] Widget added to home screen (optional)

---

## 📝 Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2024 | Initial release |
| - Accurate prayer times | - | - |
| - Glassmorphism UI | - | - |
| - Home widget | - | - |
| - Offline capability | - | - |

---

## 🙏 Final Notes

This app is created to help you:
- ✨ Never miss a prayer time
- 🕌 Stay connected to your faith
- 🌍 Accurate calculations for Bangladesh
- 📱 Works completely offline
- 🎨 Beautiful, modern design

**Use it, enjoy it, share it!**

May Allah accept from us all. ❤️

---

**Questions? Check README.md or GITHUB_ACTIONS_GUIDE.md**

**Building successfully? Share your experience!**

---

الحمد لله رب العالمين - All praise is due to Allah, Lord of the worlds

أدام الله عليكم الخير - May Allah keep you in goodness
